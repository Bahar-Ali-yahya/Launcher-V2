package com.hyperlauncher.redmia5.ui.recents

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.databinding.ActivityRecentsBinding
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.util.IconMaskUtil

/**
 * Un launcher tiers n'a pas accès aux vraies vignettes système de l'écran Recents
 * (réservées à SystemUI). On affiche ici les applications réellement les plus
 * récemment utilisées via UsageStatsManager, qui est l'API officielle la plus proche.
 */
object UsageStatsHelper {

    fun hasPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings(context: Context) {
        try {
            context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    fun getRecentApps(context: Context, limit: Int): List<AppInfo> {
        if (!hasPermission(context)) return emptyList()
        return try {
            val events = usm.queryEvents(start, end)
            val ordered = LinkedHashSet<String>()
            val timeline = mutableListOf<Pair<Long, String>>()
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND || e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                    timeline.add(e.timeStamp to e.packageName)
                }
            }
            timeline.sortByDescending { it.first }
            timeline.forEach { ordered.add(it.second) }

            ordered.mapNotNull { pkg -> AppRepository.apps.find { it.packageName == pkg } }
                .filterNot { it.packageName == context.packageName }
                .take(limit)
        } catch (e: Exception) {
            emptyList()
        }
    }
}

class RecentsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecentsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecentsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recentsBack.setOnClickListener { finish() }
        binding.recentsList.layoutManager = LinearLayoutManager(this)
        binding.recentsCloseAllBtn.setOnClickListener {
            binding.recentsList.adapter = RecentsAdapter(emptyList()) {}
            Toast.makeText(this, R.string.recents_permission_hint, Toast.LENGTH_SHORT).show()
        }

        load()
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        if (!UsageStatsHelper.hasPermission(this)) {
            binding.recentsEmptyHint.visibility = View.VISIBLE
            binding.recentsEmptyHint.setOnClickListener { UsageStatsHelper.openUsageAccessSettings(this) }
            binding.recentsList.visibility = View.GONE
            return
        }
        binding.recentsEmptyHint.visibility = View.GONE
        binding.recentsList.visibility = View.VISIBLE
        val apps = UsageStatsHelper.getRecentApps(this, 30)
        binding.recentsList.adapter = RecentsAdapter(apps) { app -> AppInfo.launch(this, app) }
    }
}

class RecentsAdapter(
    private val apps: List<AppInfo>,
    private val onClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<RecentsAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.recentIcon)
        val label: TextView = view.findViewById(R.id.recentLabel)
        val close: ImageView = view.findViewById(R.id.recentClose)
    }

    override fun getItemCount(): Int = apps.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_recent_app, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        val sizePx = (40 * holder.itemView.context.resources.displayMetrics.density).toInt()
        val shape = PrefsManager.getIconShape(holder.itemView.context)
        holder.icon.setImageBitmap(IconMaskUtil.applyMask(IconMaskUtil.drawableToBitmap(app.icon, sizePx), shape))
        holder.label.text = app.label
        holder.itemView.setOnClickListener { onClick(app) }
        holder.close.setOnClickListener {
            // On ne peut pas forcer l'arrêt d'une autre application (restriction Android) :
            // on retire seulement l'entrée de cette liste.
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                (apps as? MutableList)?.removeAt(pos)
                notifyItemRemoved(pos)
            }
        }
    }
}
