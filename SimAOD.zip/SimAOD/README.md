# SimAOD

App perso pour Redmi A5 (HyperOS / Android 15) : écran "AOD" affiché au réveil
de l'écran (image + horloge personnalisable + batterie), et bascule de la SIM
data via Shizuku.

## Ce qui marche tel quel
- Écran overlay affiché dès que l'écran s'allume, par-dessus le verrouillage
  (image de fond, horloge repositionnable/redimensionnable, % batterie).
- Bascule de la SIM utilisée pour la data, **si Shizuku est actif**.

## Limites honnêtes (matérielles/système, pas des bugs de code)
1. **Aucune app tierce ne peut détecter un appui sur un écran réellement
   éteint** — le digitizer est coupé par le firmware. L'app se déclenche donc
   sur l'allumage de l'écran (bouton power, ou "double-tap pour réveiller" si
   ton Redmi le propose dans Réglages > Écran verrouillé), pas sur un tap
   écran noir. C'est la même limite pour toutes les apps AOD tierces non
   Samsung.
2. **Police Times New Roman** : le vrai fichier est propriétaire Microsoft,
   je ne peux pas le redistribuer. L'app utilise `Typeface.SERIF`, la police à
   empattements native d'Android (visuellement proche). Si tu as un .ttf
   Times New Roman que tu possèdes légalement, dépose-le dans
   `app/src/main/res/font/` et dis-le-moi, je branche la référence.
3. **Changer la police de tout le système** (autres apps, réglages...) n'est
   pas possible sans root, quel que soit le code. Ici la police ne s'applique
   qu'à l'écran AOD de cette app.
4. **Switch SIM data via Shizuku** : fonctionne en théorie car le shell ADB a
   par défaut la permission nécessaire sur AOSP. Sur HyperOS, Xiaomi ajoute
   parfois des restrictions supplémentaires — si ça échoue, le bouton affiche
   le message d'erreur exact renvoyé par le système pour comprendre pourquoi.

## Mise en route
1. Installe l'app **Shizuku** (Play Store), démarre-la via le mode sans fil
   ADB (Réglages > Options développeur > débogage USB/sans fil) ou en root
   si tu en as un.
2. Dans SimAOD, appuie sur "Autoriser Shizuku" puis accepte.
3. Choisis ton image de fond, ajuste taille/position de l'horloge.
4. "Basculer la SIM data" bascule automatiquement sur l'autre SIM active.

## Compiler via GitHub Actions (usage perso, rien à configurer)
1. Push le projet sur `main` (ou lance le workflow manuellement dans l'onglet
   Actions).
2. Récupère l'APK dans l'artifact `SimAOD-debug`.
3. Installe-le sur ton téléphone (autorise les sources inconnues).

Aucun secret, aucun keystore à gérer : le build "debug" est signé
automatiquement par Gradle. C'est fait pour un usage perso comme le tien —
si un jour tu veux le publier sur le Play Store, il faudra repasser à un
vrai build "release" signé, mais pas avant.

## Pourquoi ce build.yml ne devrait pas planter comme les précédents
- Le projet est à la racine du repo, donc pas de détection de dossier fragile.
- Le workflow utilise `gradle/actions/setup-gradle` au lieu de `./gradlew` :
  aucun `gradle-wrapper.jar` à committer, donc pas de risque de wrapper
  manquant/corrompu (cause fréquente d'échec en CI).
