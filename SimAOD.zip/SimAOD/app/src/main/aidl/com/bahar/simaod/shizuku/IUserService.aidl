// AIDL défini par nous-mêmes (pas une interface système cachée) : Shizuku lance
// une implémentation de cette interface dans un processus qui tourne avec les
// droits du shell (ou root), ce qui permet d'appeler des méthodes normalement
// interdites à une app classique.
package com.bahar.simaod.shizuku;

interface IUserService {
    // Retourne un message de résultat ("OK" ou une erreur lisible),
    // jamais une exception brute côté appelant.
    String switchDefaultDataSim(int subscriptionId);

    void destroy();
}
