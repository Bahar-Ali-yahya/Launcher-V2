package com.bahar.simaod.shizuku

import android.telephony.SubscriptionManager

/**
 * Ce code ne tourne PAS dans le processus normal de l'app : Shizuku le lance
 * dans un processus séparé avec les droits du shell ADB (ou root si tu as
 * root). C'est ce qui permet d'appeler setDefaultDataSubId, normalement
 * réservée aux apps système.
 *
 * IMPORTANT (honnêteté technique) :
 * - Ça fonctionne sur AOSP "standard" car le shell a MODIFY_PHONE_STATE par défaut.
 * - Sur HyperOS (Xiaomi/Redmi), Xiaomi ajoute parfois des restrictions
 *   supplémentaires (MIUI Optimization / permissions renforcées). Si ça échoue,
 *   le message d'erreur renvoyé te dira pourquoi (SecurityException capturée).
 * - setDefaultDataSubId est une méthode non publique de SubscriptionManager,
 *   présente depuis Android 5.1 et stable jusqu'à Android 15, appelée ici par
 *   réflexion plutôt que par AIDL caché (ISub), pour rester robuste aux
 *   changements de version.
 */
class UserService : IUserService.Stub() {

    override fun switchDefaultDataSim(subscriptionId: Int): String {
        return try {
            val subscriptionManager = SubscriptionManager::class.java
                .getMethod("from", android.content.Context::class.java)
            // Shizuku ne fournit pas de Context ici : on passe par la méthode statique
            // getSystemContext() du framework via reflection.
            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val systemContext = activityThreadClass
                .getMethod("currentApplication")
                ?.invoke(null)
                ?: activityThreadClass.getMethod("systemMain").invoke(null)
                    .let { at -> activityThreadClass.getMethod("getSystemContext").invoke(at) }

            val ctx = systemContext as android.content.Context
            val sm = subscriptionManager.invoke(null, ctx) as SubscriptionManager

            val method = SubscriptionManager::class.java
                .getMethod("setDefaultDataSubId", Int::class.javaPrimitiveType)
            method.invoke(sm, subscriptionId)

            "OK"
        } catch (e: Exception) {
            "ECHEC: ${e.javaClass.simpleName} - ${e.message}"
        }
    }

    override fun destroy() {
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
