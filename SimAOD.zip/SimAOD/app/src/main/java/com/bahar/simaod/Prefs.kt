package com.bahar.simaod

import android.content.Context

/**
 * Petit wrapper SharedPreferences. Pas de dépendance externe (DataStore etc.)
 * pour garder la compilation simple et fiable, conformément à la demande
 * de robustesse de build.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("simaod_prefs", Context.MODE_PRIVATE)

    var backgroundImageUri: String?
        get() = sp.getString("bg_uri", null)
        set(value) = sp.edit().putString("bg_uri", value).apply()

    // Taille du texte de l'horloge, en sp. 100 = valeur par défaut (48sp).
    var clockSizePercent: Int
        get() = sp.getInt("clock_size", 100)
        set(value) = sp.edit().putInt("clock_size", value).apply()

    // Position en pourcentage de l'écran (0-100), traduite en marges à l'affichage.
    var clockXPercent: Int
        get() = sp.getInt("clock_x", 50)
        set(value) = sp.edit().putInt("clock_x", value).apply()

    var clockYPercent: Int
        get() = sp.getInt("clock_y", 20)
        set(value) = sp.edit().putInt("clock_y", value).apply()

    var dataSimSubId: Int
        get() = sp.getInt("data_sim_sub_id", -1)
        set(value) = sp.edit().putInt("data_sim_sub_id", value).apply()
}
