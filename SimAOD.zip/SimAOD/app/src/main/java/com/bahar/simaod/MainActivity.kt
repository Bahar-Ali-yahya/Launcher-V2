package com.bahar.simaod

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.bahar.simaod.shizuku.ShizukuSimSwitcher
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var txtStatus: TextView

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            // Permission persistante pour pouvoir relire l'image après redémarrage
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.backgroundImageUri = uri.toString()
            findViewById<ImageView>(R.id.imgPreview).setImageURI(uri)
        }
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        val granted = grantResult == PackageManager.PERMISSION_GRANTED
        txtStatus.text = if (granted) "Permission Shizuku accordée." else "Permission Shizuku refusée."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        txtStatus = findViewById(R.id.txtStatus)

        findViewById<ImageView>(R.id.imgPreview).apply {
            prefs.backgroundImageUri?.let { setImageURI(Uri.parse(it)) }
        }

        findViewById<Button>(R.id.btnPickImage).setOnClickListener {
            pickImage.launch("image/*")
        }

        setupSeekBars()

        findViewById<Button>(R.id.btnShizukuPermission).setOnClickListener {
            if (!ShizukuSimSwitcher.isShizukuAvailable()) {
                txtStatus.text = "Shizuku n'est pas actif. Installe l'app Shizuku (Play Store / GitHub) et démarre-la via ADB ou root, puis reviens ici."
            } else if (ShizukuSimSwitcher.hasPermission()) {
                txtStatus.text = "Permission déjà accordée."
            } else {
                ShizukuSimSwitcher.requestPermission(permissionListener)
            }
        }

        findViewById<Button>(R.id.btnSwitchSim).setOnClickListener {
            switchSim()
        }

        startAodService()
    }

    private fun setupSeekBars() {
        val seekSize = findViewById<SeekBar>(R.id.seekClockSize)
        val seekX = findViewById<SeekBar>(R.id.seekClockX)
        val seekY = findViewById<SeekBar>(R.id.seekClockY)

        seekSize.progress = prefs.clockSizePercent
        seekX.progress = prefs.clockXPercent
        seekY.progress = prefs.clockYPercent

        seekSize.setOnSeekBarChangeListener(simpleSeekListener { prefs.clockSizePercent = it })
        seekX.setOnSeekBarChangeListener(simpleSeekListener { prefs.clockXPercent = it })
        seekY.setOnSeekBarChangeListener(simpleSeekListener { prefs.clockYPercent = it })
    }

    private fun simpleSeekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    /**
     * Propose la liste des SIM disponibles et bascule la data sur celle choisie,
     * via Shizuku. Si aucune deuxième SIM ou permission manquante, message clair.
     */
    private fun switchSim() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_PHONE_STATE), 42)
            return
        }

        val sm = getSystemService(SubscriptionManager::class.java)
        val list = try {
            sm.activeSubscriptionInfoList
        } catch (e: SecurityException) {
            null
        }

        if (list.isNullOrEmpty() || list.size < 2) {
            txtStatus.text = "Une seule SIM détectée (ou permission refusée) : rien à basculer."
            return
        }

        // Prend simplement l'autre SIM que celle actuellement utilisée pour la data.
        val currentDataSubId = SubscriptionManager.getDefaultDataSubscriptionId()
        val target = list.firstOrNull { it.subscriptionId != currentDataSubId } ?: list[0]

        txtStatus.text = "Basculement en cours vers la SIM ${target.simSlotIndex + 1}…"
        ShizukuSimSwitcher.switchDataSim(target.subscriptionId) { result ->
            runOnUiThread {
                txtStatus.text = if (result == "OK") {
                    "SIM data basculée avec succès sur la SIM ${target.simSlotIndex + 1}."
                } else {
                    "Échec : $result"
                }
            }
        }
    }

    private fun startAodService() {
        val intent = Intent(this, AodForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
