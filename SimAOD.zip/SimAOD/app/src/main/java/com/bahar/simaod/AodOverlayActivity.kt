package com.bahar.simaod

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.BatteryManager
import android.os.Bundle
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextClock
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AodOverlayActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) {
                findViewById<TextView>(R.id.txtBattery).text = "${level * 100 / scale}%"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aod_overlay)
        prefs = Prefs(this)

        setupShowOverLockscreen()
        applyBackgroundImage()
        applyClockSettings()

        // Un simple appui sur l'écran AOD ferme l'overlay et laisse apparaître
        // le vrai écran de verrouillage (PIN/schéma) en dessous.
        findViewById<FrameLayout>(android.R.id.content).setOnClickListener { finish() }

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun setupShowOverLockscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }

    private fun applyBackgroundImage() {
        val uriString = prefs.backgroundImageUri ?: return
        try {
            findViewById<ImageView>(R.id.imgBackground).setImageURI(Uri.parse(uriString))
        } catch (e: SecurityException) {
            // permission perdue (ex: image supprimée) : on laisse le fond noir
        }
    }

    private fun applyClockSettings() {
        val clock = findViewById<TextClock>(R.id.clock)

        // Taille : 100% = 48sp (valeur de base définie dans le layout)
        val baseSizeSp = 48f
        clock.textSize = baseSizeSp * (prefs.clockSizePercent / 100f)

        // Police "Times New Roman" : le vrai fichier de police Times New Roman
        // est une police propriétaire Microsoft qu'on ne peut pas redistribuer
        // dans une app. On utilise donc Typeface.SERIF, la police à empattements
        // fournie par Android, visuellement très proche. Si tu as le droit
        // d'utiliser un fichier .ttf Times New Roman que tu possèdes déjà, tu
        // peux le déposer dans res/font/ et je le référence ici à la place.
        clock.typeface = Typeface.SERIF
        findViewById<TextView>(R.id.txtBattery).typeface = Typeface.SERIF

        // Position : on convertit un pourcentage (0-100) en marges par rapport
        // à l'écran, pour positionner l'horloge où tu veux.
        val displayMetrics = resources.displayMetrics
        val params = clock.layoutParams as FrameLayout.LayoutParams
        params.leftMargin = (displayMetrics.widthPixels * prefs.clockXPercent / 100f).toInt()
        params.topMargin = (displayMetrics.heightPixels * prefs.clockYPercent / 100f).toInt()
        clock.layoutParams = params
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: IllegalArgumentException) {
            // déjà désenregistré
        }
    }
}
