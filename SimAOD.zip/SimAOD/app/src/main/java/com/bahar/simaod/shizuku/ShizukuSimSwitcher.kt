package com.bahar.simaod.shizuku

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * Point d'entrée simple pour l'UI : demander la permission Shizuku, puis
 * basculer la SIM data. Si Shizuku n'est pas installé/actif, on le signale
 * clairement plutôt que de planter.
 */
object ShizukuSimSwitcher {

    private const val REQUEST_CODE = 1414

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission(listener: Shizuku.OnRequestPermissionResultListener) {
        Shizuku.addRequestPermissionResultListener(listener)
        Shizuku.requestPermission(REQUEST_CODE)
    }

    /**
     * Lance le UserService via Shizuku et demande le switch de SIM.
     * `callback` reçoit "OK" ou un message d'erreur lisible.
     */
    fun switchDataSim(subscriptionId: Int, callback: (String) -> Unit) {
        if (!isShizukuAvailable()) {
            callback("Shizuku n'est pas actif sur ce téléphone (installe l'app Shizuku et démarre-la via ADB ou root).")
            return
        }
        if (!hasPermission()) {
            callback("Permission Shizuku non accordée. Appuie d'abord sur \"Autoriser Shizuku\".")
            return
        }

        val userServiceArgs = Shizuku.UserServiceArgs(
            ComponentName("com.bahar.simaod", UserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("simswitch")
            .debuggable(false)
            .version(1)

        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                if (binder == null || !binder.pingBinder()) {
                    callback("Connexion au service Shizuku impossible.")
                    return
                }
                try {
                    val service = IUserService.Stub.asInterface(binder)
                    val result = service.switchDefaultDataSim(subscriptionId)
                    callback(result)
                } catch (e: Exception) {
                    callback("ECHEC: ${e.message}")
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                // rien à faire
            }
        }

        Shizuku.bindUserService(userServiceArgs, connection)
    }
}
