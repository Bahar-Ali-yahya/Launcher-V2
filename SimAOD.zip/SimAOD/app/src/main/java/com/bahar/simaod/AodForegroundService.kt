package com.bahar.simaod

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * IMPORTANT (limite honnête d'Android) :
 * Un téléphone ne délivre AUCUN évènement tactile à une app quand l'écran est
 * réellement éteint — ce n'est pas une limite de ce code, c'est le matériel/
 * l'OS qui coupe le digitizer. Ce que font les AOD "tap to show" (Samsung, etc.)
 * repose sur un capteur bas-niveau géré par le firmware du fabricant, non
 * exposé aux apps tierces.
 *
 * Ce service prend donc l'approche réaliste : il écoute ACTION_SCREEN_ON
 * (déclenché par un appui sur le bouton power, OU par le geste "double-tap
 * pour réveiller" si ton Redmi A5 le propose dans Réglages > Écran de
 * verrouillage) et affiche IMMÉDIATEMENT l'écran AOD par-dessus le
 * verrouillage, avant que tu ne voies le vrai écran de verrouillage.
 */
class AodForegroundService : Service() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_ON) {
                val overlayIntent = Intent(context, AodOverlayActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                context.startActivity(overlayIntent)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannelIfNeeded()
        startForeground(1, buildNotification())
        registerReceiver(receiver, IntentFilter(Intent.ACTION_SCREEN_ON))
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            // déjà désenregistré
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "simaod_service"
    }
}
