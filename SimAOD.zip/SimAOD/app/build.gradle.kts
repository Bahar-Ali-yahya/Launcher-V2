plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bahar.simaod"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bahar.simaod"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Usage perso uniquement (installé à la main sur ton téléphone) : pas besoin
    // d'un vrai keystore de release ni de secrets GitHub. Le build "debug"
    // d'Android Studio/Gradle est signé automatiquement avec une clé de debug
    // générée toute seule au premier build — largement suffisant pour installer
    // l'app sur ton propre Redmi A5.
    buildTypes {
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Shizuku : permet d'exécuter certains appels système (ex: switch de SIM data)
    // sans root, à condition que l'utilisateur ait Shizuku actif (via ADB ou root).
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
