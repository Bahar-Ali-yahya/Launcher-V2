# Uchiwa AI — Projet Android compilable sur GitHub Actions

## Compiler l'APK sur GitHub
1. Crée un nouveau dépôt GitHub.
2. Téléverse le contenu de ce ZIP à la racine du dépôt (pas le ZIP lui-même).
3. Ouvre **Actions**, active les workflows si GitHub le demande.
4. Lance **Build Uchiwa APK** ou pousse un commit sur `main`.
5. À la fin, ouvre l'exécution et télécharge l'artefact **Uchiwa-debug-apk**.
6. Décompresse-le et installe `app-debug.apk` sur Android.

Le workflow utilise JDK 17 et Android Gradle Plugin 8.7.3.

## Inclus
- Interface Android Uchiwa.
- Chat et historique local.
- Préférences personnalisées : catégories autorisées, catégories à bloquer et instructions.
- Réglages enregistrés localement.
- Configuration d'une API de chat compatible OpenAI (endpoint + nom du modèle).
- Sélecteur Android pour images, vidéos, audio et fichiers.
- Workflow GitHub Actions qui compile et publie l'APK comme artefact.

## Limites à connaître
Ce dépôt est un socle extensible, pas un modèle d'IA complet. Le chat nécessite un endpoint compatible configuré. Les fichiers peuvent être sélectionnés, mais leur contenu n'est pas encore automatiquement analysé. L'analyse et la génération d'images/vidéos, l'audio, la recherche web, l'exécution de code et l'inférence IA totalement locale nécessitent l'intégration de modèles et de moteurs spécialisés. La génération vidéo locale n'est généralement pas réaliste sur un téléphone d'entrée de gamme.

Les règles personnalisées sont transmises comme instructions au modèle connecté; elles ne remplacent pas les restrictions internes au modèle ou au fournisseur. N'enregistre pas de clés API dans un dépôt public. Pour une startup, préfère un backend sécurisé pour gérer les secrets.
