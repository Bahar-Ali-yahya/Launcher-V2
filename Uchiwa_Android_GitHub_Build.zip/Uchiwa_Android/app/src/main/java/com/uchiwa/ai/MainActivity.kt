package com.uchiwa.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 17, 27)
    private val panel = Color.rgb(29, 29, 46)
    private val accent = Color.rgb(139, 92, 246)
    private val fg = Color.rgb(246, 245, 255)
    private val muted = Color.rgb(178, 177, 199)
    private lateinit var root: LinearLayout
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private val prefs by lazy { getSharedPreferences("uchiwa", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showChat() }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16), dp(12), dp(16), dp(12)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = title; textSize = 24f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, dp(48), 1f))
        top.addView(Button(this).apply { text = "⚙"; setTextColor(fg); setBackgroundColor(panel); setOnClickListener { showSettings() } }, LinearLayout.LayoutParams(dp(54), dp(44)))
        root.addView(top); setContentView(root)
    }

    private fun showChat() {
        base("Uchiwa AI")
        root.addView(TextView(this).apply { text = "Ton assistant personnalisable"; textSize = 13f; setTextColor(muted) })
        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(6)) }
        listOf("Image", "Vidéo", "Audio", "Fichier").forEach { name ->
            shortcuts.addView(Button(this).apply {
                text = name; textSize = 11f; setTextColor(fg); setBackgroundColor(panel)
                setOnClickListener { launchPicker(name) }
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        root.addView(shortcuts)
        scroll = ScrollView(this)
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        scroll.addView(messages); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val history = prefs.getString("history", "") ?: ""
        if (history.isBlank()) addBubble("Uchiwa", "Bienvenue ! Configure un moteur IA dans ⚙ pour discuter. Tes préférences sont enregistrées localement. Les fichiers peuvent être sélectionnés, mais leur analyse nécessite un moteur multimodal intégré.")
        else history.split("\\n---\\n").filter { it.contains("::") }.forEach { val p = it.split("::", limit = 2); addBubble(p[0], p[1], false) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "Demande quelque chose…"; setHintTextColor(muted); setTextColor(fg); textSize = 15f; setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(panel) }
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        row.addView(Button(this).apply { text = "➤"; textSize = 20f; setTextColor(Color.WHITE); setBackgroundColor(accent); setOnClickListener { sendMessage() } }, LinearLayout.LayoutParams(dp(60), dp(52)).apply { setMargins(dp(8), 0, 0, 0) })
        root.addView(row)
    }

    private fun launchPicker(kind: String) {
        val mime = when (kind) { "Image" -> "image/*"; "Vidéo" -> "video/*"; "Audio" -> "audio/*"; else -> "*/*" }
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime }, 41) }
        catch (_: Exception) { toast("Sélecteur de fichiers indisponible.") }
    }

    @Deprecated("Legacy picker callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            addBubble("Système", "Fichier sélectionné : ${uri.lastPathSegment ?: "fichier"}.\nSon analyse automatique doit encore être intégrée.")
        }
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        addBubble("Toi", prompt)
        val endpoint = prefs.getString("endpoint", "") ?: ""
        if (endpoint.isBlank()) { addBubble("Uchiwa", "Aucun moteur configuré. Ouvre ⚙ pour définir un endpoint compatible et un nom de modèle."); return }
        addBubble("Uchiwa", "Réflexion en cours…")
        val model = prefs.getString("model", "model-name") ?: "model-name"
        thread {
            val answer = try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 120000; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val system = buildString {
                    append("Tu es Uchiwa AI. Respecte les préférences personnalisées de l'utilisateur dans la mesure permise par le modèle et le service.\n")
                    val allowed = prefs.getString("allowed", "") ?: ""
                    val blocked = prefs.getString("blocked", "") ?: ""
                    val rules = prefs.getString("rules", "") ?: ""
                    if (allowed.isNotBlank()) append("Préférences de catégories autorisées : $allowed\n")
                    if (blocked.isNotBlank()) append("Préférences de catégories à bloquer : $blocked\n")
                    if (rules.isNotBlank()) append("Instructions personnalisées : $rules\n")
                }
                val body = JSONObject().put("model", model).put("stream", false).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", prompt))).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(response)
                json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                    ?: json.optJSONObject("message")?.optString("content")
                    ?: "Réponse API non reconnue : ${response.take(250)}"
            } catch (e: Exception) { "Erreur de connexion : ${e.message}. Vérifie l'endpoint et le réseau." }
            runOnUiThread {
                if (messages.childCount > 0) {
                    val last = messages.getChildAt(messages.childCount - 1)
                    if (last is TextView && last.text.toString().startsWith("Uchiwa\\nRéflexion")) messages.removeView(last)
                }
                addBubble("Uchiwa", answer)
            }
        }
    }

    private fun addBubble(who: String, body: String, save: Boolean = true) {
        val bubble = TextView(this).apply { text = "$who\n$body"; textSize = 14f; setTextColor(fg); setPadding(dp(13), dp(10), dp(13), dp(10)); setBackgroundColor(if (who == "Toi") Color.rgb(52, 42, 88) else panel) }
        messages.addView(bubble, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        if (save) {
            val old = prefs.getString("history", "") ?: ""
            val line = "$who::${body.replace("\n", " ")}"
            prefs.edit().putString("history", (old.split("\n---\n").filter { it.isNotBlank() } + line).takeLast(100).joinToString("\n---\n")).apply()
        }
    }

    private fun showSettings() {
        base("Configuration")
        root.addView(TextView(this).apply { text = "Configure ton assistant une fois. Les choix restent sur ce téléphone. L'API doit accepter le format OpenAI Chat Completions."; setTextColor(muted); textSize = 13f })
        val endpoint = field("Endpoint API", prefs.getString("endpoint", "") ?: "")
        val model = field("Nom du modèle", prefs.getString("model", "") ?: "")
        val allowed = field("Catégories que je souhaite autoriser", prefs.getString("allowed", "") ?: "", 2)
        val blocked = field("Catégories que je souhaite bloquer", prefs.getString("blocked", "") ?: "", 2)
        val rules = field("Mes instructions personnalisées", prefs.getString("rules", "") ?: "", 4)
        root.addView(TextView(this).apply { text = "Ces règles sont transmises comme instructions au modèle connecté. Elles ne remplacent pas les limites du modèle ou du fournisseur. N'inscris pas de clé secrète dans un dépôt public."; setTextColor(muted); textSize = 12f; setPadding(0, dp(8), 0, dp(8)) })
        root.addView(Button(this).apply {
            text = "Enregistrer ma configuration"; setTextColor(Color.WHITE); setBackgroundColor(accent)
            setOnClickListener {
                prefs.edit().putString("endpoint", endpoint.text.toString().trim()).putString("model", model.text.toString().trim().ifBlank { "model-name" })
                    .putString("allowed", allowed.text.toString().trim()).putString("blocked", blocked.text.toString().trim()).putString("rules", rules.text.toString().trim()).apply()
                toast("Configuration enregistrée"); showChat()
            }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, dp(10), 0, dp(8)) })
        root.addView(Button(this).apply { text = "Effacer l'historique"; setTextColor(fg); setBackgroundColor(panel); setOnClickListener { prefs.edit().remove("history").apply(); showChat() } })
        root.addView(Button(this).apply { text = "Retour au chat"; setTextColor(fg); setBackgroundColor(panel); setOnClickListener { showChat() } })
    }

    private fun field(label: String, initial: String, lines: Int = 1): EditText {
        root.addView(TextView(this).apply { text = label; setTextColor(fg); textSize = 13f; setPadding(0, dp(10), 0, dp(4)) })
        return EditText(this).apply {
            hint = label; setHintTextColor(muted); setTextColor(fg); setText(initial); setBackgroundColor(panel)
            setPadding(dp(10), dp(7), dp(10), dp(7)); minLines = lines; gravity = if (lines > 1) Gravity.TOP else Gravity.CENTER_VERTICAL
            root.addView(this, LinearLayout.LayoutParams(-1, dp(if (lines > 1) 78 else 50)))
        }
    }
}
