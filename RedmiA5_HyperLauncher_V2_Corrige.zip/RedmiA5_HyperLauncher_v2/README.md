# Redmi A5 HyperLauncher V2

Version 2 du launcher Android inspiré de l'esthétique Redmi/HyperOS.

## Ajouts V2
- Interface pensée pour la navigation par gestes : haut = applications, bas = centre de contrôle, gauche = barre latérale.
- Tiroir d'applications réel avec recherche et lancement des applications installées.
- Centre de contrôle avec Wi-Fi/Internet, données mobiles/Internet, Bluetooth, torche, mode avion, localisation, rotation, mode sombre et batterie.
- Barre latérale avec raccourci Game Booster, applications et fenêtre flottante.
- Game Booster intégré à l'interface du launcher : mode performance, lancement rapide et fenêtre flottante.
- Fenêtre flottante interne au launcher pour prévisualiser une application/outil.
- Optimisé pour rester léger sur un Redmi A5.

## Limites Android
Un launcher classique ne peut pas remplacer le panneau système Quick Settings ni forcer certaines bascules protégées. Les boutons Wi-Fi et données mobiles ouvrent donc le panneau Internet officiel. Les vraies fenêtres flottantes au-dessus d'autres applications et les fonctions système complètes de Game Turbo nécessitent des permissions/éléments OEM supplémentaires.

## Compilation
Depuis la racine du projet :

    gradle assembleDebug

APK :

    app/build/outputs/apk/debug/app-debug.apk
