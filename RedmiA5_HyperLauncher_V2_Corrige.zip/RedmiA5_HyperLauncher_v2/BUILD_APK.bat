@echo off
setlocal
cd /d "%~dp0"
title Redmi A5 HyperLauncher V2 - Build APK
set "ANDROID_SDK_ROOT=C:\Android\Sdk"
set "ANDROID_HOME=C:\Android\Sdk"
set "PATH=%ANDROID_SDK_ROOT%\platform-tools;%ANDROID_SDK_ROOT%\cmdline-tools\latest\bin;%PATH%"
set "GRADLE_EXE=C:\Android\Gradle\gradle-8.10.2\bin\gradle.bat"
if not exist "%GRADLE_EXE%" (
 echo Gradle n'est pas encore installe.
 echo Lance d'abord SETUP_AND_BUILD.bat
 pause
 exit /b 1
)
call "%GRADLE_EXE%" --no-daemon assembleDebug
if errorlevel 1 (
 echo Compilation echouee.
 pause
 exit /b 1
)
echo.
echo APK : %CD%\app\build\outputs\apk\debug\app-debug.apk
pause
