package com.bahar.hyperlauncher

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var root: View
    private lateinit var home: View
    private lateinit var drawer: View
    private lateinit var control: View
    private lateinit var side: View
    private lateinit var game: View
    private lateinit var floating: View
    private var torchOn = false
    private var dark = false
    private var performance = false
    private var downX = 0f
    private var downY = 0f
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        drawer = findViewById(R.id.appDrawer)
        control = findViewById(R.id.controlPanel)
        side = findViewById(R.id.sideBar)
        game = findViewById(R.id.gameBoosterPanel)
        floating = findViewById(R.id.floatingWindow)
        updateClock()
        setupGestures()
        setupButtons()
        loadApps("")
    }

    private fun updateClock() {
        val r = object : Runnable {
            override fun run() {
                val now = Date()
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
                val date = SimpleDateFormat("EEEE d MMMM", Locale.FRENCH).format(now).replaceFirstChar { it.uppercase() }
                findViewById<TextView>(R.id.time).text = time
                findViewById<TextView>(R.id.date).text = date
                findViewById<TextView>(R.id.panelTime).text = time
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(r)
    }

    private fun setupGestures() {
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; true }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (kotlin.math.abs(dy) > 130 && kotlin.math.abs(dy) > kotlin.math.abs(dx)) {
                        if (dy < 0) showDrawer() else showControl()
                    } else if (kotlin.math.abs(dx) > 130 && kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                        if (dx < 0) showSide() else closeOverlays()
                    }
                    true
                }
                else -> true
            }
        }
        findViewById<EditText>(R.id.search).setOnClickListener { showDrawer() }
        findViewById<TextView>(R.id.dockDrawer).setOnClickListener { showDrawer() }
        findViewById<TextView>(R.id.dockGame).setOnClickListener { showGame() }
        findViewById<ImageButton>(R.id.settings).setOnClickListener { open(Settings.ACTION_SETTINGS) }
    }

    private fun setupButtons() {
        findViewById<TextView>(R.id.drawerBack).setOnClickListener { closeOverlays() }
        findViewById<EditText>(R.id.drawerSearch).addTextChangedListener(SimpleTextWatcher { loadApps(it) })
        findViewById<TextView>(R.id.closePanel).setOnClickListener { closeOverlays() }
        findViewById<Button>(R.id.wifi).setOnClickListener { open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) }
        findViewById<Button>(R.id.data).setOnClickListener { open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) }
        findViewById<Button>(R.id.bluetooth).setOnClickListener { open(Settings.ACTION_BLUETOOTH_SETTINGS) }
        findViewById<Button>(R.id.airplane).setOnClickListener { open(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
        findViewById<Button>(R.id.location).setOnClickListener { open(Settings.ACTION_LOCATION_SOURCE_SETTINGS) }
        findViewById<Button>(R.id.rotate).setOnClickListener { open(Settings.ACTION_DISPLAY_SETTINGS) }
        findViewById<Button>(R.id.battery).setOnClickListener { open(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
        findViewById<Button>(R.id.flash).setOnClickListener { toggleTorch() }
        findViewById<Button>(R.id.dark).setOnClickListener { toggleDark() }
        findViewById<Button>(R.id.gameBooster).setOnClickListener { showGame() }
        findViewById<TextView>(R.id.sideGame).setOnClickListener { showGame() }
        findViewById<TextView>(R.id.sideApps).setOnClickListener { showDrawer() }
        findViewById<TextView>(R.id.sideFloating).setOnClickListener { floating.visibility = View.VISIBLE }
        findViewById<TextView>(R.id.floatingClose).setOnClickListener { floating.visibility = View.GONE }
        findViewById<TextView>(R.id.gameBack).setOnClickListener { closeOverlays() }
        findViewById<Button>(R.id.performance).setOnClickListener {
            performance = !performance
            (it as Button).text = if (performance) "⚡ Mode performance : ON" else "⚡ Mode performance : OFF"
        }
        findViewById<Button>(R.id.launchGame).setOnClickListener { launchGame() }
        findViewById<Button>(R.id.floatingGame).setOnClickListener { floating.visibility = View.VISIBLE }
    }

    private fun showDrawer() { home.visibility = View.GONE; drawer.visibility = View.VISIBLE; control.visibility = View.GONE; side.visibility = View.GONE; game.visibility = View.GONE }
    private fun showControl() { home.visibility = View.GONE; drawer.visibility = View.GONE; control.visibility = View.VISIBLE; side.visibility = View.GONE; game.visibility = View.GONE }
    private fun showSide() { side.visibility = View.VISIBLE }
    private fun showGame() { home.visibility = View.GONE; drawer.visibility = View.GONE; control.visibility = View.GONE; side.visibility = View.GONE; game.visibility = View.VISIBLE }
    private fun closeOverlays() { home.visibility = View.VISIBLE; drawer.visibility = View.GONE; control.visibility = View.GONE; side.visibility = View.GONE; game.visibility = View.GONE; floating.visibility = View.GONE }

    private fun open(action: String) { try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            findViewById<Button>(R.id.flash).text = if (torchOn) "Torche : ON" else "Torche"
        } catch (_: Exception) { Toast.makeText(this, "Torche indisponible", Toast.LENGTH_SHORT).show() }
    }

    private fun toggleDark() {
        dark = !dark
        val bg = if (dark) 0xFF10151C.toInt() else 0xFFF6F8FC.toInt()
        root.setBackgroundColor(bg)
        Toast.makeText(this, if (dark) "Mode sombre activé" else "Mode clair activé", Toast.LENGTH_SHORT).show()
    }

    private fun launchGame() {
        val games = packageManager.getInstalledApplications(0).filter { packageManager.getLaunchIntentForPackage(it.packageName) != null && packageManager.getApplicationLabel(it).toString().contains("PUBG", true) }
        if (games.isNotEmpty()) {
            startActivity(packageManager.getLaunchIntentForPackage(games.first().packageName))
        } else {
            Toast.makeText(this, "Aucun jeu PUBG trouvé. Tu peux lancer un autre jeu depuis Applications.", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadApps(query: String) {
        val grid = findViewById<GridView>(R.id.appsGrid)
        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.loadLabel(packageManager).toString().contains(query, true) }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
        val names = apps.map { it.loadLabel(packageManager).toString() }
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                v.minimumHeight = 78
                (v as TextView).gravity = android.view.Gravity.CENTER
                v.textSize = 12f
                return v
            }
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, position, _ -> startActivity(packageManager.getLaunchIntentForPackage(apps[position].activityInfo.packageName)) }
    }

    private class SimpleTextWatcher(val onText: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onText(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
