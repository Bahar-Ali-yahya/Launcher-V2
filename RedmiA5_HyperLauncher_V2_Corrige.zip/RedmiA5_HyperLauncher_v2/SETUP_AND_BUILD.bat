@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Redmi A5 HyperLauncher V2 - SDK + APK

echo ==========================================
echo   Redmi A5 HyperLauncher V2
 echo  SDK Android + compilation APK
 echo ==========================================
echo.

where java >nul 2>&1
if errorlevel 1 (
  echo [ERREUR] Java/JDK n'est pas reconnu.
  echo Installe JDK 17 puis relance ce fichier.
  pause
  exit /b 1
)

set "ANDROID_SDK_ROOT=C:\Android\Sdk"
set "ANDROID_HOME=C:\Android\Sdk"
set "SDKMANAGER=C:\Android\Sdk\cmdline-tools\latest\bin\sdkmanager.exe"
set "GRADLE_HOME=C:\Android\Gradle\gradle-8.10.2"
set "GRADLE_EXE=%GRADLE_HOME%\bin\gradle.bat"
set "PATH=%ANDROID_SDK_ROOT%\platform-tools;%ANDROID_SDK_ROOT%\cmdline-tools\latest\bin;%PATH%"

if not exist "%SDKMANAGER%" (
  echo [ERREUR] sdkmanager.exe introuvable :
  echo %SDKMANAGER%
  echo.
  echo Verifie que le fichier existe exactement a cet emplacement.
  pause
  exit /b 1
)

echo [1/3] Installation des composants Android...
call "%SDKMANAGER%" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
if errorlevel 1 (
  echo [ERREUR] Installation du SDK echouee.
  pause
  exit /b 1
)

echo.
echo [2/3] Licences Android...
call "%SDKMANAGER%" --licenses

if not exist "%GRADLE_EXE%" (
  echo.
  echo [3/3] Telechargement de Gradle 8.10.2...
  if not exist "C:\Android\Gradle" mkdir "C:\Android\Gradle"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-8.10.2-bin.zip'; $o='C:\Android\Gradle\gradle-8.10.2-bin.zip'; Invoke-WebRequest -Uri $u -OutFile $o"
  if errorlevel 1 (
    echo [ERREUR] Impossible de telecharger Gradle.
    pause
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath 'C:\Android\Gradle\gradle-8.10.2-bin.zip' -DestinationPath 'C:\Android\Gradle' -Force"
  del /q "C:\Android\Gradle\gradle-8.10.2-bin.zip" >nul 2>&1
)

echo.
echo Compilation de l'APK...
call "%GRADLE_EXE%" --no-daemon assembleDebug
if errorlevel 1 (
  echo.
  echo [ERREUR] Compilation echouee.
  pause
  exit /b 1
)

echo.
echo ==========================================
echo   APK CREE AVEC SUCCES !
echo ==========================================
echo.
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
echo.
pause
