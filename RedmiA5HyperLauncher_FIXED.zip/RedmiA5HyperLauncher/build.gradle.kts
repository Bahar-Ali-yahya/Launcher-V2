plugins {
    id("com.android.application") version "9.3.0" apply false
    // Avec AGP 9+, le support Kotlin est intégré : plus besoin du plugin org.jetbrains.kotlin.android
}
