package com.hyperlauncher.redmia5.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable

object IconMaskUtil {

    fun drawableToBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, sizePx, sizePx)
        drawable.draw(canvas)
        return bitmap
    }

    /**
     * shape : "circle", "squircle", "teardrop" ou "rounded_square" (par défaut)
     */
    fun applyMask(source: Bitmap, shape: String): Bitmap {
        val size = minOf(source.width, source.height)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        val f = size.toFloat()

        when (shape) {
            "circle" -> path.addCircle(f / 2f, f / 2f, f / 2f, Path.Direction.CW)
            "squircle" -> path.addRoundRect(RectF(0f, 0f, f, f), f * 0.38f, f * 0.38f, Path.Direction.CW)
            "teardrop" -> path.addRoundRect(
                RectF(0f, 0f, f, f),
                floatArrayOf(f * 0.5f, f * 0.5f, f * 0.5f, f * 0.5f, f * 0.5f, f * 0.5f, f * 0.06f, f * 0.06f),
                Path.Direction.CW
            )
            else -> path.addRoundRect(RectF(0f, 0f, f, f), f * 0.22f, f * 0.22f, Path.Direction.CW)
        }

        canvas.drawPath(path, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        val srcRect = Rect(0, 0, source.width, source.height)
        val dstRect = Rect(0, 0, size, size)
        canvas.drawBitmap(source, srcRect, dstRect, paint)
        return output
    }
}
