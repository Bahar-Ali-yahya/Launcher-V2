package com.hyperlauncher.redmia5.ui.drawer

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.ui.recents.UsageStatsHelper
import com.hyperlauncher.redmia5.util.IconMaskUtil

class AppDrawerFragment : Fragment(R.layout.fragment_app_drawer) {

    var onAppClick: ((AppInfo) -> Unit)? = null
    var onAppLongClick: ((AppInfo, View) -> Unit)? = null

    private lateinit var grid: RecyclerView
    private var currentTab = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        grid = view.findViewById(R.id.drawerGrid)
        grid.layoutManager = GridLayoutManager(requireContext(), PrefsManager.getDrawerColumns(requireContext()))

        val tabs = view.findViewById<TabLayout>(R.id.drawerTabs)
        listOf("Toutes", "Récentes", "Favoris", "Catégories").forEach { tabs.addTab(tabs.newTab().setText(it)) }

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) { currentTab = tab.position; refresh("") }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        val search = view.findViewById<EditText>(R.id.drawerSearchInput)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { refresh(s?.toString().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        refresh("")
    }

    fun refresh(query: String) {
        if (!::grid.isInitialized) return
        val ctx = requireContext()
        val base: List<AppInfo> = when (currentTab) {
            1 -> UsageStatsHelper.getRecentApps(ctx, 20)
            2 -> {
                val favs = PrefsManager.getFavorites(ctx)
                AppRepository.apps.filter { it.key in favs }
            }
            else -> AppRepository.apps
        }
        val filtered = if (query.isBlank()) base else base.filter { it.label.lowercase().contains(query.lowercase()) }

        val data: List<Any> = if (currentTab == 3 && query.isBlank()) {
            buildCategorized(filtered)
        } else {
            filtered
        }

        (grid.layoutManager as? GridLayoutManager)?.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (data.getOrNull(position) is String) (grid.layoutManager as GridLayoutManager).spanCount else 1
        }

        grid.adapter = DrawerAdapter(
            data,
            onAppClick = { onAppClick?.invoke(it) },
            onAppLongClick = { app, v -> onAppLongClick?.invoke(app, v) }
        )
    }

    private fun buildCategorized(apps: List<AppInfo>): List<Any> {
        val games = apps.filter { it.isGame }
        val others = apps.filterNot { it.isGame }
        val result = mutableListOf<Any>()
        if (games.isNotEmpty()) { result.add("Jeux"); result.addAll(games) }
        if (others.isNotEmpty()) { result.add("Autres applications"); result.addAll(others) }
        return result
    }
}

private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

class DrawerAdapter(
    private val data: List<Any>,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppLongClick: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_APP = 1
    }

    class AppVH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.iconImage)
        val label: TextView = view.findViewById(R.id.iconLabel)
    }

    class HeaderVH(view: View) : RecyclerView.ViewHolder(view)

    override fun getItemViewType(position: Int): Int =
        if (data[position] is String) TYPE_HEADER else TYPE_APP

    override fun getItemCount(): Int = data.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            HeaderVH(LayoutInflater.from(parent.context).inflate(R.layout.item_category_header, parent, false))
        } else {
            AppVH(LayoutInflater.from(parent.context).inflate(R.layout.item_app_icon, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = data[position]
        if (holder is HeaderVH && item is String) {
            (holder.itemView as TextView).text = item
        } else if (holder is AppVH && item is AppInfo) {
            val ctx = holder.itemView.context
            val sizePx = ctx.dp(52)
            val shape = PrefsManager.getIconShape(ctx)
            val bmp = IconMaskUtil.drawableToBitmap(item.icon, sizePx)
            holder.icon.setImageBitmap(IconMaskUtil.applyMask(bmp, shape))
            holder.label.text = item.label
            holder.itemView.setOnClickListener { onAppClick(item) }
            holder.itemView.setOnLongClickListener { onAppLongClick(item, it); true }
        }
    }
}
