package com.hyperlauncher.redmia5.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hyperlauncher.redmia5.data.AppRepository

/**
 * Une application installée doit apparaître automatiquement, une application
 * désinstallée doit disparaître automatiquement : ce récepteur rafraîchit
 * le répertoire réel des applications dès qu'Android signale un changement.
 */
class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AppRepository.refresh(context.applicationContext)
    }
}
