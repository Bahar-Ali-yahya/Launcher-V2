package com.hyperlauncher.redmia5.ui.sidebar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.ui.MainActivity
import com.hyperlauncher.redmia5.util.IconMaskUtil

class SidebarService : Service() {

    private var windowManager: WindowManager? = null
    private var tabView: View? = null
    private var panelView: View? = null
    private var expanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showTab()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!PrefsManager.getSidebarEnabled(this)) {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllViews()
    }

    private fun windowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showTab() {
        val wm = windowManager ?: return
        val widthPx = (10 * resources.displayMetrics.density).toInt()
        val heightPx = (64 * resources.displayMetrics.density).toInt()
        val isLeft = PrefsManager.getSidebarPosition(this) == "left"

        val tab = View(this).apply {
            setBackgroundColor(0x665EE6C9)
        }
        val params = WindowManager.LayoutParams(
            widthPx, heightPx, windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (isLeft) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        }
        tab.setOnClickListener { toggleExpanded() }
        tab.setOnTouchListener(DragTouchListener(wm, params, verticalOnly = true) { wm.updateViewLayout(tab, params) }::onTouch)

        wm.addView(tab, params)
        tabView = tab
    }

    private fun toggleExpanded() {
        if (expanded) collapse() else expand()
    }

    private fun expand() {
        val wm = windowManager ?: return
        if (panelView != null) return
        expanded = true

        val widthPx = (PrefsManager.getSidebarWidthDp(this) * resources.displayMetrics.density).toInt()
        val isLeft = PrefsManager.getSidebarPosition(this) == "left"
        val alphaFloat = PrefsManager.getSidebarAlpha(this) / 100f

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card_dark)
            alpha = alphaFloat
            setPadding(12, 24, 12, 24)
        }

        val keys = PrefsManager.getSidebarApps(this)
        val iconPx = (40 * resources.displayMetrics.density).toInt()
        keys.forEach { key ->
            val app = AppRepository.findByKey(key) ?: return@forEach
            val icon = android.widget.ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(iconPx, iconPx).apply { setMargins(8, 10, 8, 10) }
                setImageBitmap(IconMaskUtil.applyMask(IconMaskUtil.drawableToBitmap(app.icon, iconPx), PrefsManager.getIconShape(this@SidebarService)))
                setOnClickListener {
                    launchApp(app)
                    collapse()
                }
            }
            container.addView(icon)
        }

        val params = WindowManager.LayoutParams(
            widthPx, WindowManager.LayoutParams.WRAP_CONTENT, windowType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (isLeft) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        }

        wm.addView(container, params)
        panelView = container

        // Ferme le panneau si l'utilisateur touche en dehors
        container.setOnClickListener { collapse() }
    }

    private fun collapse() {
        expanded = false
        panelView?.let { windowManager?.removeView(it) }
        panelView = null
    }

    private fun launchApp(app: AppInfo) {
        try {
            val intent = app.launchIntent()
            startActivity(intent)
        } catch (e: Exception) { /* application désinstallée entre-temps */ }
    }

    private fun removeAllViews() {
        tabView?.let { windowManager?.removeView(it) }
        panelView?.let { windowManager?.removeView(it) }
        tabView = null
        panelView = null
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "sidebar_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, getString(R.string.sidebar_notification_channel), NotificationManager.IMPORTANCE_MIN)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.sidebar_notification_title))
            .setSmallIcon(R.drawable.ic_search)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object { private const val NOTIF_ID = 4201 }
}

/** Permet de déplacer verticalement la petite languette le long du bord de l'écran. */
private class DragTouchListener(
    private val wm: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val verticalOnly: Boolean,
    private val onUpdate: () -> Unit
) {
    private var startY = 0
    private var touchY = 0f

    fun onTouch(view: View, event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startY = params.y
                touchY = event.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                params.y = startY + (event.rawY - touchY).toInt()
                onUpdate()
            }
            MotionEvent.ACTION_UP -> {
                if (kotlin.math.abs(event.rawY - touchY) < 8) view.performClick()
            }
        }
        return true
    }
}
