package com.hyperlauncher.redmia5.ui.folder

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.FolderRepository
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.model.FolderInfo
import com.hyperlauncher.redmia5.ui.picker.AppPickerDialogFragment
import com.hyperlauncher.redmia5.util.IconMaskUtil

class FolderDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_FOLDER_ID = "folder_id"
        private const val ARG_PREFILL_APP = "prefill_app"

        fun newInstance(folderId: String? = null, prefillAppKey: String? = null): FolderDialogFragment {
            val f = FolderDialogFragment()
            f.arguments = Bundle().apply {
                putString(ARG_FOLDER_ID, folderId)
                putString(ARG_PREFILL_APP, prefillAppKey)
            }
            return f
        }
    }

    var onChanged: (() -> Unit)? = null

    private lateinit var folder: FolderInfo
    private lateinit var appsGrid: RecyclerView
    private var isNew = false

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()
        val view = LayoutInflater.from(ctx).inflate(R.layout.dialog_folder, null)

        val folderId = arguments?.getString(ARG_FOLDER_ID)
        val prefillApp = arguments?.getString(ARG_PREFILL_APP)

        folder = if (folderId != null) {
            FolderRepository.getAll(ctx).find { it.id == folderId }
                ?: FolderRepository.create(ctx, getString(R.string.new_folder_default_name))
        } else {
            isNew = true
            FolderRepository.create(ctx, getString(R.string.new_folder_default_name)).also { newFolder ->
                if (prefillApp != null) FolderRepository.addApp(ctx, newFolder.id, prefillApp)
            }
        }
        // recharge pour être sûr d'avoir la version à jour (avec l'app préremplie)
        folder = FolderRepository.getAll(ctx).find { it.id == folder.id } ?: folder

        val nameInput = view.findViewById<EditText>(R.id.folderNameInput)
        nameInput.setText(folder.name)

        appsGrid = view.findViewById(R.id.folderAppsGrid)
        appsGrid.layoutManager = GridLayoutManager(ctx, 4)
        bindGrid()

        view.findViewById<TextView>(R.id.folderSaveBtn).setOnClickListener {
            FolderRepository.rename(ctx, folder.id, nameInput.text.toString().ifBlank { getString(R.string.new_folder_default_name) })
            onChanged?.invoke()
            dismiss()
        }

        view.findViewById<TextView>(R.id.folderDeleteBtn).setOnClickListener {
            FolderRepository.delete(ctx, folder.id)
            onChanged?.invoke()
            dismiss()
        }

        return Dialog(ctx, R.style.Theme_HyperLauncher_FloatingDialog).apply { setContentView(view) }
    }

    private fun bindGrid() {
        val ctx = requireContext()
        val apps = folder.appKeys.mapNotNull { AppRepository.findByKey(it) }
        appsGrid.adapter = FolderAppsAdapter(
            apps,
            onLaunch = { app -> com.hyperlauncher.redmia5.model.AppInfo.launch(ctx, app); dismiss() },
            onRemove = { app ->
                FolderRepository.removeApp(ctx, folder.id, app.key)
                folder.appKeys.remove(app.key)
                bindGrid()
            },
            onAddClick = {
                val picker = AppPickerDialogFragment.newInstance(
                    getString(R.string.menu_add_to_folder),
                    folder.appKeys.toList()
                )
                picker.onConfirm = { selected ->
                    selected.forEach { FolderRepository.addApp(ctx, folder.id, it) }
                    folder = FolderRepository.getAll(ctx).find { it.id == folder.id } ?: folder
                    bindGrid()
                }
                picker.show(childFragmentManager, "app_picker")
            }
        )
    }
}

private class FolderAppsAdapter(
    private val apps: List<AppInfo>,
    private val onLaunch: (AppInfo) -> Unit,
    private val onRemove: (AppInfo) -> Unit,
    private val onAddClick: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val TYPE_APP = 0
    private val TYPE_ADD = 1

    override fun getItemCount(): Int = apps.size + 1
    override fun getItemViewType(position: Int) = if (position < apps.size) TYPE_APP else TYPE_ADD

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_icon, parent, false)
        return object : RecyclerView.ViewHolder(view) {}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val icon = holder.itemView.findViewById<ImageView>(R.id.iconImage)
        val label = holder.itemView.findViewById<TextView>(R.id.iconLabel)
        val sizePx = (48 * holder.itemView.context.resources.displayMetrics.density).toInt()
        icon.layoutParams.width = sizePx
        icon.layoutParams.height = sizePx

        if (position < apps.size) {
            val app = apps[position]
            icon.setImageBitmap(IconMaskUtil.applyMask(IconMaskUtil.drawableToBitmap(app.icon, sizePx), "rounded_square"))
            label.text = app.label
            holder.itemView.setOnClickListener { onLaunch(app) }
            holder.itemView.setOnLongClickListener { onRemove(app); true }
        } else {
            icon.setImageResource(R.drawable.ic_close)
            icon.rotation = 45f
            label.text = ""
            holder.itemView.setOnClickListener { onAddClick() }
        }
    }
}
