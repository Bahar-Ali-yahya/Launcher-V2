package com.hyperlauncher.redmia5.ui.home

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.FolderRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.model.FolderInfo
import com.hyperlauncher.redmia5.util.IconMaskUtil
import kotlin.math.ceil

sealed class HomeItem {
    data class AppItem(val app: AppInfo) : HomeItem()
    data class FolderItem(val folder: FolderInfo) : HomeItem()

    val label: String
        get() = when (this) {
            is AppItem -> app.label
            is FolderItem -> folder.name
        }
}

object HomeItemsProvider {
    /** Applications réelles qui ne sont dans aucun dossier + les dossiers, triés ensemble. */
    fun build(context: android.content.Context): List<HomeItem> {
        val folders = FolderRepository.getAll(context)
        val appsInFolders = folders.flatMap { it.appKeys }.toSet()
        val topLevelApps = AppRepository.apps.filter { it.key !in appsInFolders }
        val items = mutableListOf<HomeItem>()
        folders.forEach { items.add(HomeItem.FolderItem(it)) }
        topLevelApps.forEach { items.add(HomeItem.AppItem(it)) }
        return items.sortedBy { it.label.lowercase() }
    }

    fun pageSize(context: android.content.Context): Int =
        (PrefsManager.getGridColumns(context) * PrefsManager.getGridRows(context)).coerceAtLeast(1)

    fun pageCount(context: android.content.Context): Int {
        val total = build(context).size
        val size = pageSize(context)
        return ceil(total.coerceAtLeast(1).toDouble() / size).toInt().coerceAtLeast(1)
    }

    fun generateFolderPreview(context: android.content.Context, folder: FolderInfo, sizePx: Int): Bitmap {
        val output = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
        canvas.drawRoundRect(RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat()), sizePx * 0.28f, sizePx * 0.28f, bgPaint)
        val apps = folder.appKeys.mapNotNull { AppRepository.findByKey(it) }.take(4)
        val half = sizePx / 2
        val pad = (sizePx * 0.09f).toInt()
        apps.forEachIndexed { i, app ->
            val bmp = IconMaskUtil.drawableToBitmap(app.icon, half - pad * 2)
            val left = (i % 2) * half + pad
            val top = (i / 2) * half + pad
            canvas.drawBitmap(bmp, left.toFloat(), top.toFloat(), null)
        }
        return output
    }
}

/** Une page de la grille d'accueil (ViewPager2). */
class HomePageFragment : Fragment(R.layout.fragment_home_page) {

    companion object {
        private const val ARG_PAGE = "page"
        fun newInstance(page: Int): HomePageFragment {
            val f = HomePageFragment()
            f.arguments = Bundle().apply { putInt(ARG_PAGE, page) }
            return f
        }
    }

    var onAppClick: ((AppInfo) -> Unit)? = null
    var onAppLongClick: ((AppInfo, View) -> Unit)? = null
    var onFolderClick: ((FolderInfo) -> Unit)? = null
    var onFolderLongClick: ((FolderInfo, View) -> Unit)? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val page = requireArguments().getInt(ARG_PAGE)
        val ctx = requireContext()
        val columns = PrefsManager.getGridColumns(ctx)
        val pageSize = HomeItemsProvider.pageSize(ctx)
        val all = HomeItemsProvider.build(ctx)
        val start = page * pageSize
        val end = (start + pageSize).coerceAtMost(all.size)
        val pageItems = if (start < end) all.subList(start, end) else emptyList()

        val grid = view.findViewById<RecyclerView>(R.id.pageGrid)
        grid.layoutManager = GridLayoutManager(ctx, columns)
        grid.adapter = AppGridAdapter(
            ctx, pageItems,
            onAppClick = { onAppClick?.invoke(it) },
            onAppLongClick = { app, v -> onAppLongClick?.invoke(app, v) },
            onFolderClick = { onFolderClick?.invoke(it) },
            onFolderLongClick = { f, v -> onFolderLongClick?.invoke(f, v) }
        )
    }
}

/** Pagine l'écran d'accueil (plusieurs pages, comme un vrai launcher). */
class HomePagerAdapter(
    private val activity: FragmentActivity
) : FragmentStateAdapter(activity) {
    var onAppClick: ((AppInfo) -> Unit)? = null
    var onAppLongClick: ((AppInfo, View) -> Unit)? = null
    var onFolderClick: ((FolderInfo) -> Unit)? = null
    var onFolderLongClick: ((FolderInfo, View) -> Unit)? = null

    override fun getItemCount(): Int = HomeItemsProvider.pageCount(activity)

    override fun createFragment(position: Int): Fragment {
        val f = HomePageFragment.newInstance(position)
        f.onAppClick = onAppClick
        f.onAppLongClick = onAppLongClick
        f.onFolderClick = onFolderClick
        f.onFolderLongClick = onFolderLongClick
        return f
    }
}

/** Grille d'icônes : vraies applications (PackageManager) + dossiers avec aperçu réel. */
class AppGridAdapter(
    private val context: android.content.Context,
    private val items: List<HomeItem>,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppLongClick: (AppInfo, View) -> Unit,
    private val onFolderClick: (FolderInfo) -> Unit,
    private val onFolderLongClick: (FolderInfo, View) -> Unit
) : RecyclerView.Adapter<AppGridAdapter.VH>() {

    private val iconSizePx = (PrefsManager.getIconSizeDp(context) * context.resources.displayMetrics.density).toInt()
    private val showLabels = PrefsManager.getShowLabels(context)
    private val labelSizeSp = PrefsManager.getLabelSizeSp(context).toFloat()
    private val iconShape = PrefsManager.getIconShape(context)

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.iconImage)
        val label: TextView = view.findViewById(R.id.iconLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_icon, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.icon.layoutParams.width = iconSizePx
        holder.icon.layoutParams.height = iconSizePx
        holder.label.visibility = if (showLabels) View.VISIBLE else View.GONE
        holder.label.textSize = labelSizeSp

        when (item) {
            is HomeItem.AppItem -> {
                val bmp = IconMaskUtil.drawableToBitmap(item.app.icon, iconSizePx)
                holder.icon.setImageBitmap(IconMaskUtil.applyMask(bmp, iconShape))
                holder.label.text = item.app.label
                holder.itemView.setOnClickListener { onAppClick(item.app) }
                holder.itemView.setOnLongClickListener { onAppLongClick(item.app, it); true }
            }
            is HomeItem.FolderItem -> {
                val bmp = HomeItemsProvider.generateFolderPreview(context, item.folder, iconSizePx)
                holder.icon.setImageBitmap(bmp)
                holder.label.text = item.folder.name
                holder.itemView.setOnClickListener { onFolderClick(item.folder) }
                holder.itemView.setOnLongClickListener { onFolderLongClick(item.folder, it); true }
            }
        }
    }
}
