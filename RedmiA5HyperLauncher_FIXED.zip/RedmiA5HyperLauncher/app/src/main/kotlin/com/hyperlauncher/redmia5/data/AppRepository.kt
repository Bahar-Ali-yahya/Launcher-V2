package com.hyperlauncher.redmia5.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.ui.gamebooster.GameDetector

/**
 * Source unique de vérité pour la liste des applications réellement installées.
 * Aucune donnée fictive : tout provient de PackageManager.queryIntentActivities.
 */
object AppRepository {
    var apps: List<AppInfo> = emptyList()
        private set

    private val listeners = mutableListOf<() -> Unit>()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun refresh(context: Context) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolveInfos = try {
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        } catch (e: Exception) {
            pm.queryIntentActivities(intent, 0)
        }

        apps = resolveInfos.mapNotNull { ri ->
            try {
                val pkg = ri.activityInfo.packageName
                AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    activityName = ri.activityInfo.name,
                    icon = ri.loadIcon(pm),
                    isGame = GameDetector.isLikelyGame(pm, pkg)
                )
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.label.lowercase() }

        listeners.forEach { it() }
    }

    fun findByKey(key: String): AppInfo? = apps.find { it.key == key }

    fun search(query: String): List<AppInfo> {
        if (query.isBlank()) return apps
        val q = query.trim().lowercase()
        return apps.filter { it.label.lowercase().contains(q) }
    }

    fun games(): List<AppInfo> = apps.filter { it.isGame }
}
