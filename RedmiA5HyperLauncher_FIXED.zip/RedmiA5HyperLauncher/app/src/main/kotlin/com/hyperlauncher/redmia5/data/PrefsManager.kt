package com.hyperlauncher.redmia5.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Toutes les préférences du launcher. SharedPreferences est sauvegardé automatiquement
 * par Android sur le disque : les réglages survivent au redémarrage du téléphone
 * et du launcher, sans code supplémentaire.
 */
object PrefsManager {
    const val FILE = "hyperlauncher_prefs"

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- Grille ----
    fun getGridColumns(context: Context) = prefs(context).getInt("grid_columns", 4)
    fun setGridColumns(context: Context, value: Int) = prefs(context).edit().putInt("grid_columns", value).apply()

    fun getGridRows(context: Context) = prefs(context).getInt("grid_rows", 5)
    fun setGridRows(context: Context, value: Int) = prefs(context).edit().putInt("grid_rows", value).apply()

    fun getIconSizeDp(context: Context) = prefs(context).getInt("icon_size_dp", 52)
    fun setIconSizeDp(context: Context, value: Int) = prefs(context).edit().putInt("icon_size_dp", value).apply()

    fun getLabelSizeSp(context: Context) = prefs(context).getInt("label_size_sp", 11)
    fun setLabelSizeSp(context: Context, value: Int) = prefs(context).edit().putInt("label_size_sp", value).apply()

    fun getShowLabels(context: Context) = prefs(context).getBoolean("show_labels", true)
    fun setShowLabels(context: Context, value: Boolean) = prefs(context).edit().putBoolean("show_labels", value).apply()

    fun getIconSpacingDp(context: Context) = prefs(context).getInt("icon_spacing_dp", 12)
    fun setIconSpacingDp(context: Context, value: Int) = prefs(context).edit().putInt("icon_spacing_dp", value).apply()

    fun getDrawerColumns(context: Context) = prefs(context).getInt("pref_drawer_columns", 4)
    fun setDrawerColumns(context: Context, value: Int) = prefs(context).edit().putInt("pref_drawer_columns", value).apply()

    // ---- Icônes ----
    fun getIconShape(context: Context) = prefs(context).getString("icon_shape", "rounded_square") ?: "rounded_square"
    fun setIconShape(context: Context, value: String) = prefs(context).edit().putString("icon_shape", value).apply()

    // ---- Apparence / thème ----
    fun getThemeMode(context: Context) = prefs(context).getString("theme_mode", "system") ?: "system"
    fun setThemeMode(context: Context, value: String) = prefs(context).edit().putString("theme_mode", value).apply()

    fun getAccentSource(context: Context) = prefs(context).getString("accent_source", "wallpaper") ?: "wallpaper"
    fun setAccentSource(context: Context, value: String) = prefs(context).edit().putString("accent_source", value).apply()

    fun getManualAccent(context: Context) = prefs(context).getInt("accent_manual", 0xFF5EE6C9.toInt())
    fun setManualAccent(context: Context, value: Int) = prefs(context).edit().putInt("accent_manual", value).apply()

    fun getCachedWallpaperAccent(context: Context): Int? =
        if (prefs(context).contains("accent_wallpaper")) prefs(context).getInt("accent_wallpaper", 0) else null
    fun setCachedWallpaperAccent(context: Context, value: Int) = prefs(context).edit().putInt("accent_wallpaper", value).apply()

    fun getPanelTransparency(context: Context) = prefs(context).getInt("panel_transparency", 85)
    fun setPanelTransparency(context: Context, value: Int) = prefs(context).edit().putInt("panel_transparency", value).apply()

    fun getBorderIntensity(context: Context) = prefs(context).getInt("border_intensity", 40)
    fun setBorderIntensity(context: Context, value: Int) = prefs(context).edit().putInt("border_intensity", value).apply()

    // ---- Animations ----
    fun getAnimationsEnabled(context: Context) = prefs(context).getBoolean("animations_enabled", true)
    fun setAnimationsEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean("animations_enabled", value).apply()

    fun getAnimationSpeed(context: Context) = prefs(context).getFloat("animation_speed", 1.0f)
    fun setAnimationSpeed(context: Context, value: Float) = prefs(context).edit().putFloat("animation_speed", value).apply()

    // ---- Dock ----
    fun getDockApps(context: Context): List<String> {
        val raw = prefs(context).getString("dock_apps", null) ?: return DEFAULT_DOCK
        return raw.split("|").filter { it.isNotBlank() }
    }
    fun setDockApps(context: Context, keys: List<String>) =
        prefs(context).edit().putString("dock_apps", keys.joinToString("|")).apply()

    // ---- Gestes ----
    fun getGestureAction(context: Context, gesture: String, default: String) =
        prefs(context).getString("gesture_$gesture", default) ?: default
    fun setGestureAction(context: Context, gesture: String, action: String) =
        prefs(context).edit().putString("gesture_$gesture", action).apply()

    // ---- Barre latérale ----
    fun getSidebarEnabled(context: Context) = prefs(context).getBoolean("sidebar_enabled", false)
    fun setSidebarEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean("sidebar_enabled", value).apply()

    fun getSidebarPosition(context: Context) = prefs(context).getString("sidebar_position", "right") ?: "right"
    fun setSidebarPosition(context: Context, value: String) = prefs(context).edit().putString("sidebar_position", value).apply()

    fun getSidebarWidthDp(context: Context) = prefs(context).getInt("sidebar_width_dp", 56)
    fun setSidebarWidthDp(context: Context, value: Int) = prefs(context).edit().putInt("sidebar_width_dp", value).apply()

    fun getSidebarAlpha(context: Context) = prefs(context).getInt("sidebar_alpha", 90)
    fun setSidebarAlpha(context: Context, value: Int) = prefs(context).edit().putInt("sidebar_alpha", value).apply()

    fun getSidebarApps(context: Context): List<String> {
        val raw = prefs(context).getString("sidebar_apps", null) ?: return DEFAULT_DOCK
        return raw.split("|").filter { it.isNotBlank() }
    }
    fun setSidebarApps(context: Context, keys: List<String>) =
        prefs(context).edit().putString("sidebar_apps", keys.joinToString("|")).apply()

    // ---- Centre de contrôle ----
    fun getControlCenterOrder(context: Context): List<String> {
        val raw = prefs(context).getString("cc_order", null)
        return if (raw != null) raw.split(",") else DEFAULT_CC_ORDER
    }
    fun setControlCenterOrder(context: Context, order: List<String>) =
        prefs(context).edit().putString("cc_order", order.joinToString(",")).apply()

    // ---- Fond d'écran ----
    fun getWallpaperList(context: Context): List<String> {
        val raw = prefs(context).getString("wallpaper_list", null) ?: return emptyList()
        return raw.split("|").filter { it.isNotBlank() }
    }
    fun addWallpaperUri(context: Context, uri: String) {
        val list = getWallpaperList(context).toMutableList()
        if (!list.contains(uri)) list.add(uri)
        prefs(context).edit().putString("wallpaper_list", list.joinToString("|")).apply()
    }
    fun getAutoWallpaperEnabled(context: Context) = prefs(context).getBoolean("auto_wallpaper", false)
    fun setAutoWallpaperEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean("auto_wallpaper", value).apply()
    fun getAutoWallpaperIntervalMin(context: Context) = prefs(context).getInt("auto_wallpaper_interval", 60)
    fun setAutoWallpaperIntervalMin(context: Context, value: Int) = prefs(context).edit().putInt("auto_wallpaper_interval", value).apply()
    fun getAutoWallpaperIndex(context: Context) = prefs(context).getInt("auto_wallpaper_index", 0)
    fun setAutoWallpaperIndex(context: Context, value: Int) = prefs(context).edit().putInt("auto_wallpaper_index", value).apply()

    // ---- Game Booster ----
    fun getGbBlockNotificationsDefault(context: Context) = prefs(context).getBoolean("pref_gb_block_notifications_default", true)
    fun setGbBlockNotificationsDefault(context: Context, value: Boolean) = prefs(context).edit().putBoolean("pref_gb_block_notifications_default", value).apply()

    // ---- Favoris ----
    fun getFavorites(context: Context): Set<String> =
        prefs(context).getStringSet("favorites", emptySet()) ?: emptySet()

    fun toggleFavorite(context: Context, appKey: String) {
        val current = getFavorites(context).toMutableSet()
        if (!current.add(appKey)) current.remove(appKey)
        prefs(context).edit().putStringSet("favorites", current).apply()
    }

    // ---- Sauvegarde / réinitialisation ----
    fun exportAll(context: Context): Map<String, *> = prefs(context).all
    fun resetAll(context: Context) = prefs(context).edit().clear().apply()

    // ---- Widgets ajoutés à l'accueil ----
    fun getWidgetsVisible(context: Context) = prefs(context).getBoolean("pref_widgets_visible", true)
    fun getWidgetIds(context: Context): List<Int> {
        val raw = prefs(context).getString("widget_ids", null) ?: return emptyList()
        return raw.split(",").filter { it.isNotBlank() }.mapNotNull { it.toIntOrNull() }
    }
    fun addWidgetId(context: Context, id: Int) {
        val list = getWidgetIds(context).toMutableList()
        if (!list.contains(id)) list.add(id)
        prefs(context).edit().putString("widget_ids", list.joinToString(",")).apply()
    }
    fun removeWidgetId(context: Context, id: Int) {
        val list = getWidgetIds(context).filterNot { it == id }
        prefs(context).edit().putString("widget_ids", list.joinToString(",")).apply()
    }

    val DEFAULT_DOCK = listOf<String>()
    val DEFAULT_CC_ORDER = listOf(
        "wifi", "mobile_data", "bluetooth", "airplane", "flashlight",
        "auto_rotate", "silent", "location", "hotspot", "battery_saver"
    )
}
