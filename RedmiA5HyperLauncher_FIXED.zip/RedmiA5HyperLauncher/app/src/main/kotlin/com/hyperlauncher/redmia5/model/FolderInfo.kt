package com.hyperlauncher.redmia5.model

import org.json.JSONArray
import org.json.JSONObject

data class FolderInfo(
    val id: String,
    var name: String,
    val appKeys: MutableList<String> = mutableListOf()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("apps", JSONArray(appKeys))
    }

    companion object {
        fun fromJson(json: JSONObject): FolderInfo {
            val apps = mutableListOf<String>()
            val arr = json.optJSONArray("apps")
            if (arr != null) {
                for (i in 0 until arr.length()) apps.add(arr.getString(i))
            }
            return FolderInfo(
                id = json.getString("id"),
                name = json.getString("name"),
                appKeys = apps
            )
        }
    }
}
