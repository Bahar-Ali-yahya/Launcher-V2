package com.hyperlauncher.redmia5.data

import android.content.Context
import com.hyperlauncher.redmia5.model.FolderInfo
import org.json.JSONArray
import java.util.UUID

object FolderRepository {
    private const val FILE = "hyperlauncher_folders"
    private const val KEY = "folders_json"

    fun getAll(context: Context): MutableList<FolderInfo> {
        val prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<FolderInfo>()
        for (i in 0 until arr.length()) {
            list.add(FolderInfo.fromJson(arr.getJSONObject(i)))
        }
        return list
    }

    private fun saveAll(context: Context, folders: List<FolderInfo>) {
        val arr = JSONArray()
        folders.forEach { arr.put(it.toJson()) }
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun create(context: Context, name: String): FolderInfo {
        val folders = getAll(context)
        val folder = FolderInfo(id = UUID.randomUUID().toString(), name = name)
        folders.add(folder)
        saveAll(context, folders)
        return folder
    }

    fun rename(context: Context, folderId: String, newName: String) {
        val folders = getAll(context)
        folders.find { it.id == folderId }?.name = newName
        saveAll(context, folders)
    }

    fun delete(context: Context, folderId: String) {
        val folders = getAll(context).filterNot { it.id == folderId }
        saveAll(context, folders)
    }

    fun addApp(context: Context, folderId: String, appKey: String) {
        val folders = getAll(context)
        folders.find { it.id == folderId }?.let {
            if (!it.appKeys.contains(appKey)) it.appKeys.add(appKey)
        }
        saveAll(context, folders)
    }

    fun removeApp(context: Context, folderId: String, appKey: String) {
        val folders = getAll(context)
        folders.find { it.id == folderId }?.appKeys?.remove(appKey)
        saveAll(context, folders)
    }
}
