package com.hyperlauncher.redmia5.ui.settings

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceManager
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.FolderRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.databinding.ActivitySettingsBinding
import com.hyperlauncher.redmia5.theme.ThemeManager
import com.hyperlauncher.redmia5.ui.MainActivity
import com.hyperlauncher.redmia5.ui.picker.AppPickerDialogFragment
import com.hyperlauncher.redmia5.util.WallpaperRotationManager
import org.json.JSONObject

class SettingsActivity : AppCompatActivity(), PreferenceFragmentCompat.OnPreferenceStartScreenCallback {

    companion object {
        const val EXTRA_ROOT_KEY = "root_key"
    }

    private lateinit var binding: ActivitySettingsBinding

    private val pickWallpaperLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) applyWallpaper(uri) }

    private val exportLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) exportSettingsTo(uri) }

    private val importLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) importSettingsFrom(uri) }

    private val overlayLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { /* l'utilisateur revient des réglages système, rien à faire ici */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.applyNightMode(this)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.settingsToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.settingsToolbar.setNavigationOnClickListener { onSupportBackPressed() }

        if (savedInstanceState == null) {
            val rootKey = intent.getStringExtra(EXTRA_ROOT_KEY)
            val fragment = RootSettingsFragment()
            if (rootKey != null) fragment.arguments = bundleOf(PreferenceFragmentCompat.ARG_PREFERENCE_ROOT to rootKey)
            supportFragmentManager.beginTransaction()
                .replace(R.id.settingsContainer, fragment, rootKey ?: "root")
                .commit()
        }
        supportFragmentManager.addOnBackStackChangedListener { updateTitle() }
    }

    private fun onSupportBackPressed() {
        if (supportFragmentManager.backStackEntryCount > 0) supportFragmentManager.popBackStack() else finish()
    }

    override fun onPreferenceStartScreen(caller: PreferenceFragmentCompat, pref: androidx.preference.PreferenceScreen): Boolean {
        val fragment = RootSettingsFragment()
        fragment.arguments = bundleOf(PreferenceFragmentCompat.ARG_PREFERENCE_ROOT to pref.key)
        supportFragmentManager.beginTransaction()
            .replace(R.id.settingsContainer, fragment, pref.key)
            .addToBackStack(pref.key)
            .commit()
        return true
    }

    private fun updateTitle() {
        binding.settingsToolbar.title = getString(R.string.settings_title)
    }

    private fun applyWallpaper(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { /* certains fournisseurs ne supportent pas la persistance, on continue quand même */ }
        try {
            contentResolver.openInputStream(uri)?.use { stream ->
                android.app.WallpaperManager.getInstance(this).setStream(stream)
            }
            PrefsManager.addWallpaperUri(this, uri.toString())
            ThemeManager.refreshWallpaperAccent(this)
            Toast.makeText(this, R.string.pref_pick_wallpaper, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportSettingsTo(uri: Uri) {
        try {
            val json = JSONObject()
            PrefsManager.exportAll(this).forEach { (k, v) -> if (v != null) json.put(k, v.toString()) }
            contentResolver.openOutputStream(uri)?.use { it.write(json.toString(2).toByteArray()) }
            Toast.makeText(this, R.string.export_success, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun importSettingsFrom(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return
            val json = JSONObject(text)
            val editor = PreferenceManager.getDefaultSharedPreferences(this).edit()
            val prefs = getSharedPreferences(PrefsManager.FILE, MODE_PRIVATE).edit()
            json.keys().forEach { key ->
                prefs.putString(key, json.getString(key))
            }
            prefs.apply()
            Toast.makeText(this, R.string.import_success, Toast.LENGTH_SHORT).show()
            recreate()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Un seul Fragment réutilisé pour toutes les catégories (imbriquées via ARG_PREFERENCE_ROOT). */
    class RootSettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            preferenceManager.sharedPreferencesName = PrefsManager.FILE
            preferenceManager.sharedPreferencesMode = MODE_PRIVATE
            setPreferencesFromResource(R.xml.preferences_root, rootKey)
            wireSpecialPreferences(rootKey)
        }

        private fun wireSpecialPreferences(rootKey: String?) {
            val ctx = requireContext()
            val act = activity as? SettingsActivity ?: return

            findPreference<Preference>("pref_theme_mode")?.setOnPreferenceChangeListener { _, newValue ->
                PrefsManager.setThemeMode(ctx, newValue as String)
                ThemeManager.applyNightMode(ctx)
                act.recreate()
                true
            }

            findPreference<Preference>("pref_manage_dock")?.setOnPreferenceClickListener {
                showPicker(getString(R.string.picker_title_dock), PrefsManager.getDockApps(ctx), 6) { selected ->
                    PrefsManager.setDockApps(ctx, selected)
                }
                true
            }

            findPreference<Preference>("pref_manage_sidebar_apps")?.setOnPreferenceClickListener {
                showPicker(getString(R.string.picker_title_sidebar), PrefsManager.getSidebarApps(ctx), 8) { selected ->
                    PrefsManager.setSidebarApps(ctx, selected)
                }
                true
            }

            findPreference<Preference>("pref_sidebar_enabled")?.setOnPreferenceChangeListener { _, newValue ->
                if (newValue == true && !Settings.canDrawOverlays(ctx)) {
                    act.overlayLauncher.launch(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
                true
            }

            findPreference<Preference>("pref_pick_wallpaper")?.setOnPreferenceClickListener {
                act.pickWallpaperLauncher.launch(arrayOf("image/*"))
                true
            }

            findPreference<Preference>("pref_auto_wallpaper")?.setOnPreferenceChangeListener { _, newValue ->
                if (newValue == true) WallpaperRotationManager.schedule(ctx) else WallpaperRotationManager.cancel(ctx)
                true
            }

            findPreference<Preference>("pref_add_widget")?.setOnPreferenceClickListener {
                val intent = Intent(ctx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("action", "add_widget")
                }
                startActivity(intent)
                true
            }

            findPreference<Preference>("pref_pick_accent")?.setOnPreferenceClickListener {
                showAccentPicker(ctx)
                true
            }

            findPreference<Preference>("pref_open_default_apps")?.setOnPreferenceClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
                true
            }

            findPreference<Preference>("pref_export_settings")?.setOnPreferenceClickListener {
                act.exportLauncher.launch("hyperlauncher_backup.json")
                true
            }

            findPreference<Preference>("pref_import_settings")?.setOnPreferenceClickListener {
                act.importLauncher.launch(arrayOf("application/json"))
                true
            }

            findPreference<Preference>("pref_reset_all")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx, R.style.Theme_HyperLauncher_FloatingDialog)
                    .setTitle(R.string.confirm_reset_title)
                    .setMessage(R.string.confirm_reset_message)
                    .setPositiveButton(R.string.yes) { _, _ ->
                        PrefsManager.resetAll(ctx)
                        act.recreate()
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
                true
            }

            if (rootKey == "screen_folders") {
                findPreference<Preference>("pref_folders_count")?.summary =
                    FolderRepository.getAll(ctx).size.toString()
            }
            if (rootKey == "screen_apps") {
                findPreference<Preference>("pref_apps_info")?.summary =
                    getString(R.string.pref_apps_realtime_info) + " (" + AppRepository.apps.size + ")"
            }
        }

        private fun showPicker(title: String, current: List<String>, max: Int, onSave: (List<String>) -> Unit) {
            val picker = AppPickerDialogFragment.newInstance(title, current, max)
            picker.onConfirm = onSave
            picker.show(childFragmentManager, "picker")
        }

        private fun showAccentPicker(ctx: android.content.Context) {
            val colors = intArrayOf(
                0xFF5EE6C9.toInt(), 0xFF5EC8F2.toInt(), 0xFF5EE688.toInt(), 0xFFF2C85E.toInt(),
                0xFFF2785E.toInt(), 0xFFE85EC8.toInt(), 0xFF8F5EE6.toInt(), 0xFFE6E05E.toInt()
            )
            val names = arrayOf("Cyan", "Bleu", "Vert", "Or", "Corail", "Rose", "Violet", "Jaune")
            AlertDialog.Builder(ctx, R.style.Theme_HyperLauncher_FloatingDialog)
                .setTitle(R.string.pref_pick_accent)
                .setItems(names) { _, which ->
                    PrefsManager.setAccentSource(ctx, "manual")
                    PrefsManager.setManualAccent(ctx, colors[which])
                    (activity as? SettingsActivity)?.recreate()
                }
                .show()
        }
    }
}
