package com.hyperlauncher.redmia5.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.theme.ThemeManager

object WallpaperRotationManager {

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, WallpaperRotationReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, 4200, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context) {
        val intervalMin = PrefsManager.getAutoWallpaperIntervalMin(context).coerceAtLeast(15)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = System.currentTimeMillis() + intervalMin * 60_000L
        // Alarme inexacte : pas besoin de la permission spéciale "alarmes exactes"
        am.setInexactRepeating(
            AlarmManager.RTC,
            triggerAt,
            intervalMin * 60_000L,
            pendingIntent(context)
        )
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
    }

    fun rotateNow(context: Context) {
        val list = PrefsManager.getWallpaperList(context)
        if (list.isEmpty()) return
        val index = PrefsManager.getAutoWallpaperIndex(context) % list.size
        try {
            val uri = Uri.parse(list[index])
            context.contentResolver.openInputStream(uri)?.use { stream ->
                WallpaperManager.getInstance(context).setStream(stream)
            }
            ThemeManager.refreshWallpaperAccent(context)
        } catch (e: Exception) {
            // URI devenue invalide (image supprimée de la galerie) : on ignore ce cycle
        }
        PrefsManager.setAutoWallpaperIndex(context, (index + 1) % list.size)
    }
}

class WallpaperRotationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        WallpaperRotationManager.rotateNow(context.applicationContext)
    }
}
