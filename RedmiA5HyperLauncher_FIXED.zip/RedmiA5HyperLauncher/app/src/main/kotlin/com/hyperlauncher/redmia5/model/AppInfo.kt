package com.hyperlauncher.redmia5.model

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

/**
 * Représente une vraie application installée sur le téléphone.
 * Le nom, l'icône, le package et l'activité proviennent directement du PackageManager,
 * jamais de données fictives.
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable,
    val isGame: Boolean = false
) {
    val componentName: ComponentName
        get() = ComponentName(packageName, activityName)

    /** Clé stable utilisée pour la sauvegarde (dock, dossiers, tiroir favoris) */
    val key: String
        get() = "$packageName/$activityName"

    fun launchIntent(): Intent =
        Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = componentName
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

    fun openAppInfoIntent(): Intent =
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = android.net.Uri.fromParts("package", packageName, null)
        }

    fun uninstallIntent(): Intent =
        Intent(Intent.ACTION_DELETE).apply {
            data = android.net.Uri.fromParts("package", packageName, null)
        }

    companion object {
        fun launch(context: Context, app: AppInfo) {
            try {
                context.startActivity(app.launchIntent())
            } catch (e: Exception) {
                // L'activité a pu être désinstallée entre-temps : on ignore plutôt que de planter
            }
        }
    }
}
