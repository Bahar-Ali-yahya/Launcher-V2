package com.hyperlauncher.redmia5

import android.app.Application
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.theme.ThemeManager

class HyperLauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ThemeManager.applyNightMode(this)
        AppRepository.refresh(this)
    }
}
