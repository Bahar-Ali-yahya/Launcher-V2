package com.hyperlauncher.redmia5.ui.home

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.util.IconMaskUtil

/**
 * Gère le dock inférieur : applications entièrement personnalisables par l'utilisateur
 * (ajout, suppression, remplacement) via PrefsManager.
 */
class DockController(
    private val context: Context,
    private val container: LinearLayout,
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) {
    fun render() {
        container.removeAllViews()
        val keys = PrefsManager.getDockApps(context)
        val iconSizePx = (48 * context.resources.displayMetrics.density).toInt()
        val shape = PrefsManager.getIconShape(context)

        if (keys.isEmpty()) {
            container.visibility = View.GONE
            return
        }
        container.visibility = View.VISIBLE

        keys.forEach { key ->
            val app = AppRepository.findByKey(key) ?: return@forEach
            val itemView = LayoutInflater.from(context).inflate(R.layout.item_app_icon, container, false)
            val icon = itemView.findViewById<ImageView>(R.id.iconImage)
            val label = itemView.findViewById<TextView>(R.id.iconLabel)

            icon.layoutParams.width = iconSizePx
            icon.layoutParams.height = iconSizePx
            val bmp = IconMaskUtil.drawableToBitmap(app.icon, iconSizePx)
            icon.setImageBitmap(IconMaskUtil.applyMask(bmp, shape))
            label.visibility = View.GONE // le dock reste compact, sans nom sous les icônes

            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            itemView.layoutParams = lp

            itemView.setOnClickListener { onClick(app) }
            itemView.setOnLongClickListener { onLongClick(app, it); true }
            container.addView(itemView)
        }
    }
}
