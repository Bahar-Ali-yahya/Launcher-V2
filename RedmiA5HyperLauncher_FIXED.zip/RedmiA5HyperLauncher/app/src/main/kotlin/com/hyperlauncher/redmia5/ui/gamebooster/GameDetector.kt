package com.hyperlauncher.redmia5.ui.gamebooster

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

object GameDetector {
    // Certains jeux ne déclarent pas correctement la catégorie "jeu" auprès d'Android :
    // on complète avec les packages connus les plus courants.
    private val KNOWN_GAME_PACKAGES = setOf(
        "com.tencent.ig",
        "com.pubg.imobile",
        "com.tencent.tmgp.pubgmhd",
        "com.dts.freefireth",
        "com.garena.game.codm",
        "com.supercell.clashofclans",
        "com.miHoYo.GenshinImpact",
        "com.mobile.legends",
        "com.roblox.client",
        "com.king.candycrushsaga"
    )

    fun isLikelyGame(pm: PackageManager, packageName: String): Boolean {
        if (KNOWN_GAME_PACKAGES.contains(packageName)) return true
        return try {
            val appInfo = pm.getApplicationInfo(packageName, 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }
        } catch (e: Exception) {
            false
        }
    }
}
