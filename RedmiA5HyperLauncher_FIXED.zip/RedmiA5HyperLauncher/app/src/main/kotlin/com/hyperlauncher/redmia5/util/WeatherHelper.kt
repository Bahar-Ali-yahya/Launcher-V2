package com.hyperlauncher.redmia5.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Météo réelle via Open-Meteo (aucune clé API requise). Si la position n'est pas
 * disponible ou le réseau échoue, retourne null : jamais de valeur inventée.
 */
object WeatherHelper {

    fun fetchCurrentTemperature(context: Context, onResult: (Double?) -> Unit) {
        Thread {
            val result = try {
                val (lat, lon) = lastKnownLocationOrDefault(context)
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.requestMethod = "GET"
                val body = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(body)
                json.getJSONObject("current").getDouble("temperature_2m")
            } catch (e: Exception) {
                null
            }
            Handler(Looper.getMainLooper()).post { onResult(result) }
        }.start()
    }

    private fun lastKnownLocationOrDefault(context: Context): Pair<Double, Double> {
        try {
            val granted = ActivityCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                for (provider in lm.getProviders(true)) {
                    val loc = lm.getLastKnownLocation(provider)
                    if (loc != null) return Pair(loc.latitude, loc.longitude)
                }
            }
        } catch (e: Exception) {
            // on retombe sur la position par défaut
        }
        return Pair(48.8566, 2.3522) // Paris, utilisé seulement si aucune position n'est disponible
    }
}
