package com.hyperlauncher.redmia5.ui.picker

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.util.IconMaskUtil

class AppPickerDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_TITLE = "title"
        private const val ARG_SELECTED = "selected"
        private const val ARG_MAX = "max"

        fun newInstance(title: String, preSelected: List<String>, maxSelection: Int = -1): AppPickerDialogFragment {
            val f = AppPickerDialogFragment()
            f.arguments = Bundle().apply {
                putString(ARG_TITLE, title)
                putStringArrayList(ARG_SELECTED, ArrayList(preSelected))
                putInt(ARG_MAX, maxSelection)
            }
            return f
        }
    }

    var onConfirm: ((List<String>) -> Unit)? = null
    private val selected = mutableSetOf<String>()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()
        val view = LayoutInflater.from(ctx).inflate(R.layout.dialog_app_picker, null)

        val title = arguments?.getString(ARG_TITLE).orEmpty()
        val preSelected = arguments?.getStringArrayList(ARG_SELECTED).orEmpty()
        val max = arguments?.getInt(ARG_MAX) ?: -1
        selected.addAll(preSelected)

        view.findViewById<TextView>(R.id.pickerTitle).text = title

        val list = view.findViewById<RecyclerView>(R.id.pickerList)
        list.layoutManager = LinearLayoutManager(ctx)
        val adapter = PickerAdapter(AppRepository.apps, selected, max)
        list.adapter = adapter

        view.findViewById<TextView>(R.id.pickerSaveBtn).setOnClickListener {
            onConfirm?.invoke(selected.toList())
            dismiss()
        }

        return Dialog(ctx, R.style.Theme_HyperLauncher_FullScreenDialog).apply { setContentView(view) }
    }
}

private class PickerAdapter(
    private val apps: List<AppInfo>,
    private val selected: MutableSet<String>,
    private val max: Int
) : RecyclerView.Adapter<PickerAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.rowIcon)
        val label: TextView = view.findViewById(R.id.rowLabel)
        val check: CheckBox = view.findViewById(R.id.rowCheck)
    }

    override fun getItemCount(): Int = apps.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_picker_row, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        val sizePx = (36 * holder.itemView.context.resources.displayMetrics.density).toInt()
        holder.icon.setImageBitmap(IconMaskUtil.applyMask(IconMaskUtil.drawableToBitmap(app.icon, sizePx), "rounded_square"))
        holder.label.text = app.label
        holder.check.isChecked = selected.contains(app.key)

        holder.itemView.setOnClickListener {
            if (selected.contains(app.key)) {
                selected.remove(app.key)
                holder.check.isChecked = false
            } else {
                if (max in 1..selected.size) return@setOnClickListener
                selected.add(app.key)
                holder.check.isChecked = true
            }
        }
    }
}
