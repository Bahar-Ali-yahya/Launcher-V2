package com.hyperlauncher.redmia5.ui.floating

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.ui.MainActivity

/**
 * Vraie fenêtre flottante système (overlay au-dessus des autres applications).
 * Héberge un outil du launcher lui-même (ici un mini navigateur) : Android n'autorise
 * pas une application tierce à forcer une AUTRE application quelconque dans une
 * fenêtre flottante qu'elle ne gère pas elle-même (voir pref_floating_info).
 */
class FloatingWindowService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showWindow()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { windowManager?.removeView(it) }
        floatingView = null
    }

    private fun windowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showWindow() {
        val wm = windowManager ?: return
        val density = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card_dark)
        }

        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((8 * density).toInt(), (6 * density).toInt(), (8 * density).toInt(), (6 * density).toInt())
        }
        val minimizeBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_rotate)
            layoutParams = LinearLayout.LayoutParams((20 * density).toInt(), (20 * density).toInt())
            setOnClickListener { toggleMinimized() }
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val closeBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            layoutParams = LinearLayout.LayoutParams((20 * density).toInt(), (20 * density).toInt())
            setOnClickListener { stopSelf() }
        }
        titleBar.addView(minimizeBtn)
        titleBar.addView(spacer)
        titleBar.addView(closeBtn)

        val webContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams((260 * density).toInt(), (360 * density).toInt())
        }
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            loadUrl("https://www.google.com")
        }
        webContainer.addView(webView)

        root.addView(titleBar)
        root.addView(webContainer)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 200
        }

        titleBar.setOnTouchListener(WindowDragListener(wm, lp, root) { wm.updateViewLayout(root, lp) })

        wm.addView(root, lp)
        floatingView = root
        params = lp
    }

    private var minimized = false
    private fun toggleMinimized() {
        val view = floatingView ?: return
        minimized = !minimized
        (view as? LinearLayout)?.getChildAt(1)?.visibility = if (minimized) View.GONE else View.VISIBLE
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "floating_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, getString(R.string.floating_notification_channel), NotificationManager.IMPORTANCE_MIN)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.floating_notification_title))
            .setSmallIcon(R.drawable.ic_search)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object { private const val NOTIF_ID = 4202 }
}

private class WindowDragListener(
    private val wm: WindowManager,
    private val params: WindowManager.LayoutParams,
    private val view: View,
    private val onUpdate: () -> Unit
) : View.OnTouchListener {
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = params.x
                startY = params.y
                touchX = event.rawX
                touchY = event.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                params.x = startX + (event.rawX - touchX).toInt()
                params.y = startY + (event.rawY - touchY).toInt()
                onUpdate()
            }
        }
        return true
    }
}
