package com.hyperlauncher.redmia5.ui

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.viewpager2.widget.ViewPager2
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.FolderRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.databinding.ActivityMainBinding
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.model.FolderInfo
import com.hyperlauncher.redmia5.theme.ThemeManager
import com.hyperlauncher.redmia5.ui.controlcenter.ControlCenterSheet
import com.hyperlauncher.redmia5.ui.drawer.AppDrawerFragment
import com.hyperlauncher.redmia5.ui.folder.FolderDialogFragment
import com.hyperlauncher.redmia5.ui.home.DockController
import com.hyperlauncher.redmia5.ui.home.HomeGestureListener
import com.hyperlauncher.redmia5.ui.home.HomePagerAdapter
import com.hyperlauncher.redmia5.ui.home.attachHomeGestures
import com.hyperlauncher.redmia5.ui.settings.SettingsActivity
import com.hyperlauncher.redmia5.util.WeatherHelper
import com.hyperlauncher.redmia5.widget.WidgetHostManager

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dock: DockController
    private lateinit var widgetHost: WidgetHostManager
    private var pendingWidgetId: Int = -1

    private val appsChangedListener: () -> Unit = { runOnUiThread { refreshHome() } }

    private val overlayPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { startSidebarIfEnabled() }

    private val widgetPickLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result -> onWidgetPickResult(result) }

    private val widgetBindLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingWidgetId != -1) {
            addWidgetToHome(pendingWidgetId)
        } else if (pendingWidgetId != -1) {
            widgetHost.deleteAppWidgetId(pendingWidgetId)
        }
        pendingWidgetId = -1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.applyNightMode(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        widgetHost = WidgetHostManager(this)

        setupPager()
        setupDock()
        setupSearchBar()
        setupGestures()
        setupWeather()

        AppRepository.addListener(appsChangedListener)
    }

    override fun onStart() {
        super.onStart()
        widgetHost.startListening()
        loadSavedWidgets()
    }

    override fun onStop() {
        super.onStop()
        widgetHost.stopListening()
    }

    override fun onResume() {
        super.onResume()
        ThemeManager.refreshWallpaperAccent(this)
        startSidebarIfEnabled()
    }

    override fun onDestroy() {
        super.onDestroy()
        AppRepository.removeListener(appsChangedListener)
    }

    /** Un nouvel appui sur le bouton Accueil doit ramener à l'accueil, pas relancer l'activité. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (binding.drawerContainer.isVisible) closeDrawer()
        if (intent.getStringExtra("action") == "add_widget") {
            requestAddWidget()
        } else {
            binding.pagerApps.setCurrentItem(0, true)
        }
    }

    // ---------------------------------------------------------------------
    // Grille paginée
    // ---------------------------------------------------------------------

    private fun setupPager() {
        val adapter = HomePagerAdapter(this)
        adapter.onAppClick = { AppInfo.launch(this, it) }
        adapter.onAppLongClick = { app, view -> showAppMenu(app, view) }
        adapter.onFolderClick = { openFolder(it) }
        adapter.onFolderLongClick = { folder, _ -> openFolder(folder) }
        binding.pagerApps.adapter = adapter
        binding.pagerApps.offscreenPageLimit = 1

        binding.pagerApps.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updatePageIndicator(position)
        })
        rebuildPageIndicator()
    }

    private fun refreshHome() {
        rebuildPageIndicator()
        binding.pagerApps.adapter?.notifyDataSetChanged()
        dock.render()
    }

    private fun rebuildPageIndicator() {
        binding.pageIndicator.removeAllViews()
        val count = (binding.pagerApps.adapter as? HomePagerAdapter)?.itemCount ?: 1
        val dotSizePx = (6 * resources.displayMetrics.density).toInt()
        val marginPx = (3 * resources.displayMetrics.density).toInt()
        for (i in 0 until count) {
            val dot = View(this)
            val lp = android.widget.LinearLayout.LayoutParams(dotSizePx, dotSizePx)
            lp.setMargins(marginPx, 0, marginPx, 0)
            dot.layoutParams = lp
            dot.setBackgroundResource(if (i == binding.pagerApps.currentItem) R.drawable.bg_toggle_on else R.drawable.bg_toggle_off)
            binding.pageIndicator.addView(dot)
        }
    }

    private fun updatePageIndicator(selected: Int) {
        for (i in 0 until binding.pageIndicator.childCount) {
            binding.pageIndicator.getChildAt(i)
                .setBackgroundResource(if (i == selected) R.drawable.bg_toggle_on else R.drawable.bg_toggle_off)
        }
    }

    // ---------------------------------------------------------------------
    // Dock
    // ---------------------------------------------------------------------

    private fun setupDock() {
        dock = DockController(
            this, binding.dockView,
            onClick = { AppInfo.launch(this, it) },
            onLongClick = { app, view -> showAppMenu(app, view, inDock = true) }
        )
        dock.render()
    }

    // ---------------------------------------------------------------------
    // Recherche / Tiroir
    // ---------------------------------------------------------------------

    private fun setupSearchBar() {
        binding.searchBar.setOnClickListener { openDrawer() }
    }

    private fun openDrawer() {
        if (binding.drawerContainer.isVisible) return
        val fragment = AppDrawerFragment()
        fragment.onAppClick = { AppInfo.launch(this, it); closeDrawer() }
        fragment.onAppLongClick = { app, view -> showAppMenu(app, view) }
        supportFragmentManager.beginTransaction()
            .replace(R.id.drawerContainer, fragment)
            .commitAllowingStateLoss()

        binding.drawerContainer.visibility = View.VISIBLE
        binding.drawerContainer.translationY = resources.displayMetrics.heightPixels.toFloat()
        binding.drawerContainer.animate().translationY(0f).setDuration(animDuration()).start()
    }

    private fun closeDrawer() {
        binding.drawerContainer.animate()
            .translationY(resources.displayMetrics.heightPixels.toFloat())
            .setDuration(animDuration())
            .withEndAction { binding.drawerContainer.visibility = View.GONE }
            .start()
    }

    @Deprecated("Deprecated in Java", ReplaceWith("super.onBackPressed()"))
    override fun onBackPressed() {
        if (binding.drawerContainer.isVisible) {
            closeDrawer()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun animDuration(): Long {
        if (!PrefsManager.getAnimationsEnabled(this)) return 0L
        val speed = PrefsManager.getAnimationSpeed(this).coerceAtLeast(10f)
        return (220f * (100f / speed)).toLong()
    }

    // ---------------------------------------------------------------------
    // Gestes
    // ---------------------------------------------------------------------

    private fun setupGestures() {
        val listener = HomeGestureListener(
            context = this,
            onSwipeUp = { openDrawer() },
            onSwipeDown = { ControlCenterSheet().show(supportFragmentManager, "control_center") },
            onLongPress = { showCustomizeSheet() }
        )
        binding.rootHome.attachHomeGestures(listener)
    }

    private fun showCustomizeSheet() {
        val options = arrayOf(
            getString(R.string.customize_wallpaper),
            getString(R.string.customize_widgets),
            getString(R.string.customize_settings)
        )
        AlertDialog.Builder(this, R.style.Theme_HyperLauncher_FloatingDialog)
            .setTitle(R.string.customize_home_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, SettingsActivity::class.java).putExtra(SettingsActivity.EXTRA_ROOT_KEY, "screen_wallpaper"))
                    1 -> requestAddWidget()
                    2 -> startActivity(Intent(this, SettingsActivity::class.java))
                }
            }
            .show()
    }

    // ---------------------------------------------------------------------
    // Menu contextuel d'une application (appui long)
    // ---------------------------------------------------------------------

    private fun showAppMenu(app: AppInfo, anchor: View, inDock: Boolean = false) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.menu_app_info)
        popup.menu.add(0, 2, 1, R.string.menu_add_to_folder)
        val favs = PrefsManager.getFavorites(this)
        popup.menu.add(0, 3, 2, if (app.key in favs) R.string.menu_remove_from_favorites else R.string.menu_add_to_favorites)
        if (inDock) {
            popup.menu.add(0, 4, 3, R.string.menu_remove_from_dock)
        } else {
            popup.menu.add(0, 5, 4, R.string.menu_add_to_dock)
        }
        popup.menu.add(0, 6, 5, R.string.menu_uninstall)

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> startActivity(app.openAppInfoIntent())
                2 -> showAddToFolderMenu(app, anchor)
                3 -> {
                    PrefsManager.toggleFavorite(this, app.key)
                }
                4 -> {
                    val dockKeys = PrefsManager.getDockApps(this).filterNot { it == app.key }
                    PrefsManager.setDockApps(this, dockKeys)
                    dock.render()
                }
                5 -> {
                    val dockKeys = PrefsManager.getDockApps(this).toMutableList()
                    if (!dockKeys.contains(app.key)) dockKeys.add(app.key)
                    PrefsManager.setDockApps(this, dockKeys)
                    dock.render()
                }
                6 -> startActivity(app.uninstallIntent())
            }
            true
        }
        popup.show()
    }

    private fun showAddToFolderMenu(app: AppInfo, anchor: View) {
        val folders = FolderRepository.getAll(this)
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 0, 0, R.string.menu_new_folder)
        folders.forEachIndexed { index, f -> popup.menu.add(0, index + 1, index + 1, f.name) }
        popup.setOnMenuItemClickListener { item ->
            if (item.itemId == 0) {
                FolderDialogFragment.newInstance(prefillAppKey = app.key).apply {
                    onChanged = { refreshHome() }
                }.show(supportFragmentManager, "folder")
            } else {
                val folder = folders[item.itemId - 1]
                FolderRepository.addApp(this, folder.id, app.key)
                refreshHome()
            }
            true
        }
        popup.show()
    }

    private fun openFolder(folder: FolderInfo) {
        FolderDialogFragment.newInstance(folderId = folder.id).apply {
            onChanged = { refreshHome() }
        }.show(supportFragmentManager, "folder")
    }

    // ---------------------------------------------------------------------
    // Météo réelle
    // ---------------------------------------------------------------------

    private fun setupWeather() {
        WeatherHelper.fetchCurrentTemperature(this) { temp ->
            if (temp != null) {
                binding.weatherView.text = getString(R.string.weather_format, temp.toInt())
                binding.weatherView.visibility = View.VISIBLE
            }
        }
    }

    // ---------------------------------------------------------------------
    // Barre latérale
    // ---------------------------------------------------------------------

    private fun startSidebarIfEnabled() {
        if (!PrefsManager.getSidebarEnabled(this)) return
        if (!Settings.canDrawOverlays(this)) {
            overlayPermissionLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val intent = Intent(this, com.hyperlauncher.redmia5.ui.sidebar.SidebarService::class.java)
        androidx.core.content.ContextCompat.startForegroundService(this, intent)
    }

    // ---------------------------------------------------------------------
    // Widgets réels (AppWidgetHost)
    // ---------------------------------------------------------------------

    fun requestAddWidget() {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        widgetPickLauncher.launch(widgetHost.createPickIntent(id))
    }

    private fun onWidgetPickResult(result: androidx.activity.result.ActivityResult) {
        val data = result.data
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (result.resultCode != Activity.RESULT_OK || id == -1) {
            if (pendingWidgetId != -1) widgetHost.deleteAppWidgetId(pendingWidgetId)
            pendingWidgetId = -1
            return
        }
        val info = widgetHost.appWidgetManager.getAppWidgetInfo(id)
        if (info?.configure != null) {
            pendingWidgetId = id
            val configIntent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                component = info.configure
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            widgetBindLauncher.launch(configIntent)
        } else {
            addWidgetToHome(id)
        }
    }

    private fun addWidgetToHome(appWidgetId: Int) {
        PrefsManager.addWidgetId(this, appWidgetId)
        val view = widgetHost.createHostView(appWidgetId) ?: return
        binding.widgetsContainer.addView(view)
        binding.widgetsContainer.visibility = View.VISIBLE
    }

    private fun loadSavedWidgets() {
        binding.widgetsContainer.removeAllViews()
        val ids = PrefsManager.getWidgetIds(this)
        if (ids.isEmpty() || !PrefsManager.getWidgetsVisible(this)) {
            binding.widgetsContainer.visibility = View.GONE
            return
        }
        ids.forEach { id ->
            val view = widgetHost.createHostView(id)
            if (view != null) binding.widgetsContainer.addView(view) else PrefsManager.removeWidgetId(this, id)
        }
        binding.widgetsContainer.visibility = View.VISIBLE
    }
}
