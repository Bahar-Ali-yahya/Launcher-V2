package com.hyperlauncher.redmia5.ui.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.databinding.ActivityGameBoosterBinding
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.util.IconMaskUtil

class GameBoosterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameBoosterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBoosterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.gbBack.setOnClickListener { finish() }

        val games = AppRepository.games()
        bindFeaturedGame(games)
        bindPerformanceInfo()
        bindNotificationSwitch()
        bindOtherGames(games)
    }

    private fun bindFeaturedGame(games: List<AppInfo>) {
        // Le jeu mis en avant : PUBG s'il est installé, sinon le premier jeu détecté.
        val featured = games.find { it.packageName.contains("pubg", ignoreCase = true) || it.packageName.contains("tencent.ig") }
            ?: games.firstOrNull()

        if (featured == null) {
            binding.featuredGameCard.visibility = View.GONE
            binding.gbNoGameHint.visibility = View.VISIBLE
            return
        }
        val sizePx = (48 * resources.displayMetrics.density).toInt()
        binding.featuredGameIcon.setImageBitmap(IconMaskUtil.applyMask(IconMaskUtil.drawableToBitmap(featured.icon, sizePx), PrefsManager.getIconShape(this)))
        binding.featuredGameName.text = featured.label
        binding.featuredGameLaunch.setOnClickListener { AppInfo.launch(this, featured) }
    }

    private fun bindPerformanceInfo() {
        // RAM disponible sur tout le système : Android ne permet pas à une app tierce de lire
        // la RAM utilisée par chaque autre application individuellement (voir pref_gb_info).
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val availableGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
        val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
        binding.ramValue.text = getString(R.string.ram_available) + String.format(" %.1f / %.1f Go", availableGb, totalGb)

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        binding.networkValue.text = when {
            caps == null -> "—"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Données mobiles"
            else -> "Connecté"
        }
    }

    private fun bindNotificationSwitch() {
        binding.blockNotificationsSwitch.isChecked = PrefsManager.getGbBlockNotificationsDefault(this)
        binding.blockNotificationsSwitch.setOnCheckedChangeListener { _, checked ->
            PrefsManager.setGbBlockNotificationsDefault(this, checked)
            if (checked) {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (!nm.isNotificationPolicyAccessGranted) {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            }
        }
    }

    private fun bindOtherGames(games: List<AppInfo>) {
        binding.otherGamesGrid.layoutManager = GridLayoutManager(this, 4)
        binding.otherGamesGrid.adapter = SimpleAppAdapter(games) { AppInfo.launch(this, it) }
    }
}

private class SimpleAppAdapter(
    private val apps: List<AppInfo>,
    private val onClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<SimpleAppAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.iconImage)
        val label: TextView = view.findViewById(R.id.iconLabel)
    }

    override fun getItemCount(): Int = apps.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_icon, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        val sizePx = (52 * holder.itemView.context.resources.displayMetrics.density).toInt()
        val shape = PrefsManager.getIconShape(holder.itemView.context)
        holder.icon.setImageBitmap(IconMaskUtil.applyMask(IconMaskUtil.drawableToBitmap(app.icon, sizePx), shape))
        holder.label.text = app.label
        holder.itemView.setOnClickListener { onClick(app) }
    }
}
