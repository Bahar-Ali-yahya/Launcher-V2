package com.hyperlauncher.redmia5.ui.controlcenter

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.location.LocationManagerCompat
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.PrefsManager

/** Lit/modifie les vrais réglages Android quand c'est autorisé, ouvre le bon panneau sinon. */
object QuickToggleHelper {
    private var flashlightOn = false

    fun label(id: String): Int = when (id) {
        "wifi" -> R.string.toggle_wifi
        "mobile_data" -> R.string.toggle_mobile_data
        "bluetooth" -> R.string.toggle_bluetooth
        "airplane" -> R.string.toggle_airplane
        "flashlight" -> R.string.toggle_flashlight
        "auto_rotate" -> R.string.toggle_auto_rotate
        "silent" -> R.string.toggle_silent
        "location" -> R.string.toggle_location
        "hotspot" -> R.string.toggle_hotspot
        else -> R.string.toggle_battery_saver
    }

    fun icon(id: String): Int = when (id) {
        "wifi" -> R.drawable.ic_wifi
        "mobile_data" -> R.drawable.ic_mobile_data
        "bluetooth" -> R.drawable.ic_bluetooth
        "airplane" -> R.drawable.ic_airplane
        "flashlight" -> R.drawable.ic_flashlight
        "auto_rotate" -> R.drawable.ic_rotate
        "silent" -> R.drawable.ic_silent
        "location" -> R.drawable.ic_location
        "hotspot" -> R.drawable.ic_hotspot
        else -> R.drawable.ic_battery
    }

    fun isActive(context: Context, id: String): Boolean = try {
        when (id) {
            "wifi" -> (context.getSystemService(Context.WIFI_SERVICE) as? WifiManager)?.isWifiEnabled ?: false
            "bluetooth" -> BluetoothAdapter.getDefaultAdapter()?.isEnabled ?: false
            "airplane" -> Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
            "flashlight" -> flashlightOn
            "auto_rotate" -> Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) != 0
            "silent" -> {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.ringerMode != AudioManager.RINGER_MODE_NORMAL
            }
            "location" -> {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
                LocationManagerCompat.isLocationEnabled(lm)
            }
            "battery_saver" -> (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode ?: false
            else -> false
        }
    } catch (e: Exception) {
        false
    }

    /** Retourne true si une vraie bascule a été effectuée, false si on a seulement ouvert un panneau. */
    fun handleToggle(context: Context, id: String): Boolean {
        return try {
            when (id) {
                "flashlight" -> {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val camId = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return false
                    flashlightOn = !flashlightOn
                    cm.setTorchMode(camId, flashlightOn)
                    true
                }
                "auto_rotate" -> {
                    if (!Settings.System.canWrite(context)) {
                        openIntent(context, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}")))
                        false
                    } else {
                        val current = Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
                        Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (current == 0) 1 else 0)
                        true
                    }
                }
                "silent" -> {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    if (!nm.isNotificationPolicyAccessGranted) {
                        openIntent(context, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        false
                    } else {
                        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        am.ringerMode = if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
                        true
                    }
                }
                "bluetooth" -> {
                    val adapter = BluetoothAdapter.getDefaultAdapter()
                    if (adapter == null) { false } else {
                        @Suppress("DEPRECATION")
                        if (adapter.isEnabled) adapter.disable() else adapter.enable()
                        true
                    }
                }
                "wifi" -> {
                    openIntent(context, if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS))
                    false
                }
                "mobile_data" -> { openIntent(context, Intent(Settings.ACTION_WIRELESS_SETTINGS)); false }
                "airplane" -> { openIntent(context, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)); false }
                "location" -> { openIntent(context, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); false }
                "hotspot" -> { openIntent(context, Intent("android.settings.TETHER_SETTINGS")); false }
                "battery_saver" -> { openIntent(context, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)); false }
                else -> false
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun openIntent(context: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(intent) } catch (e: Exception) { /* panneau indisponible sur cet appareil */ }
    }
}

class ControlCenterSheet : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): android.app.Dialog {
        val ctx = requireContext()
        val view = LayoutInflater.from(ctx).inflate(R.layout.sheet_control_center, null)

        val grid = view.findViewById<RecyclerView>(R.id.ccToggleGrid)
        grid.layoutManager = GridLayoutManager(ctx, 5)
        val visible = PrefsManager.getControlCenterOrder(ctx)
        grid.adapter = ToggleAdapter(visible) { grid.adapter?.notifyDataSetChanged() }

        val brightness = view.findViewById<SeekBar>(R.id.brightnessSeek)
        try {
            brightness.progress = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        } catch (e: Exception) { }
        brightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (Settings.System.canWrite(ctx)) {
                    Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress)
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val volume = view.findViewById<SeekBar>(R.id.volumeSeek)
        volume.max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        volume.progress = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        volume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        return android.app.Dialog(ctx, R.style.Theme_HyperLauncher_FloatingDialog).apply { setContentView(view) }
    }
}

private class ToggleAdapter(
    private val ids: List<String>,
    private val onToggled: () -> Unit
) : RecyclerView.Adapter<ToggleAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val bg: View = view.findViewById(R.id.toggleBg)
        val icon: ImageView = view.findViewById(R.id.toggleIcon)
        val label: TextView = view.findViewById(R.id.toggleLabel)
    }

    override fun getItemCount(): Int = ids.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_control_toggle, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val id = ids[position]
        val ctx = holder.itemView.context
        holder.icon.setImageResource(QuickToggleHelper.icon(id))
        holder.label.setText(QuickToggleHelper.label(id))
        val active = QuickToggleHelper.isActive(ctx, id)
        holder.bg.setBackgroundResource(if (active) R.drawable.bg_toggle_on else R.drawable.bg_toggle_off)

        holder.itemView.setOnClickListener {
            QuickToggleHelper.handleToggle(ctx, id)
            notifyItemChanged(position)
            onToggled()
        }
    }
}
