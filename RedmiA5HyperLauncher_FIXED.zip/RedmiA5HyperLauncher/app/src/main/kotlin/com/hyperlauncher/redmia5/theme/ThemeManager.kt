package com.hyperlauncher.redmia5.theme

import android.app.WallpaperManager
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.palette.graphics.Palette
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.util.IconMaskUtil

object ThemeManager {

    fun applyNightMode(context: Context) {
        val mode = PrefsManager.getThemeMode(context)
        val nightMode = when (mode) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }

    fun getAccentColor(context: Context): Int {
        if (PrefsManager.getAccentSource(context) == "manual") {
            return PrefsManager.getManualAccent(context)
        }
        return PrefsManager.getCachedWallpaperAccent(context)
            ?: ContextCompat.getColor(context, R.color.accent_default)
    }

    /**
     * Analyse le vrai fond d'écran du système avec Palette (AndroidX) pour en extraire
     * une couleur d'accent. Si l'accès est refusé par le fabricant, on garde l'accent par défaut
     * plutôt que d'inventer une couleur.
     */
    fun refreshWallpaperAccent(context: Context, onDone: (() -> Unit)? = null) {
        try {
            val wm = WallpaperManager.getInstance(context)
            val drawable = wm.drawable
            if (drawable == null) {
                onDone?.invoke()
                return
            }
            val bitmap = IconMaskUtil.drawableToBitmap(drawable, 128)
            Palette.from(bitmap).generate { palette ->
                val fallback = ContextCompat.getColor(context, R.color.accent_default)
                val color = palette?.vibrantSwatch?.rgb
                    ?: palette?.dominantSwatch?.rgb
                    ?: fallback
                PrefsManager.setCachedWallpaperAccent(context, color)
                onDone?.invoke()
            }
        } catch (e: SecurityException) {
            onDone?.invoke()
        } catch (e: Exception) {
            onDone?.invoke()
        }
    }
}
