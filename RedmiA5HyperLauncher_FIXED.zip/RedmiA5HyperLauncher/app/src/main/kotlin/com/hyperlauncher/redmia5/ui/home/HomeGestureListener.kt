package com.hyperlauncher.redmia5.ui.home

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import com.hyperlauncher.redmia5.data.PrefsManager
import kotlin.math.abs

class HomeGestureListener(
    private val context: Context,
    private val onSwipeUp: () -> Unit,
    private val onSwipeDown: () -> Unit,
    private val onLongPress: () -> Unit
) : GestureDetector.SimpleOnGestureListener() {

    private val minDistance = 60
    private val minVelocity = 80

    override fun onDown(e: MotionEvent): Boolean = true

    override fun onLongPress(e: MotionEvent) {
        val action = PrefsManager.getGestureAction(context, "long_press", "customize")
        if (action == "customize") onLongPress()
    }

    override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
        if (e1 == null) return false
        val dx = e2.x - e1.x
        val dy = e2.y - e1.y
        if (abs(dy) <= abs(dx)) return false
        if (abs(dy) < minDistance || abs(velocityY) < minVelocity) return false

        if (dy < 0) {
            val action = PrefsManager.getGestureAction(context, "swipe_up", "drawer")
            if (action == "drawer") onSwipeUp()
        } else {
            val action = PrefsManager.getGestureAction(context, "swipe_down", "control_center")
            if (action == "control_center" || action == "search") onSwipeDown()
        }
        return true
    }
}

/** Attache le détecteur à une vue sans bloquer ses gestes horizontaux (ViewPager2). */
fun View.attachHomeGestures(listener: HomeGestureListener) {
    val detector = GestureDetector(context, listener)
    setOnTouchListener { _, event ->
        detector.onTouchEvent(event)
        false // laisse l'événement continuer vers les enfants (ViewPager2, RecyclerView)
    }
}
