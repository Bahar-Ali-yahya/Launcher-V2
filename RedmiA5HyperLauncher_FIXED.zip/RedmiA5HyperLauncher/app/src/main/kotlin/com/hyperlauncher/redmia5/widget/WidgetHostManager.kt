package com.hyperlauncher.redmia5.widget

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent

/**
 * Encapsule AppWidgetHost, l'API officielle Android pour héberger de vrais widgets
 * d'autres applications sur un écran d'accueil personnalisé.
 */
class WidgetHostManager(private val context: Context) {
    companion object {
        const val HOST_ID = 1024
        const val REQUEST_PICK_APPWIDGET = 9001
        const val REQUEST_CREATE_APPWIDGET = 9002
        const val REQUEST_BIND_APPWIDGET = 9003
    }

    val appWidgetManager: AppWidgetManager = AppWidgetManager.getInstance(context)
    val appWidgetHost: AppWidgetHost = AppWidgetHost(context, HOST_ID)

    fun startListening() = appWidgetHost.startListening()
    fun stopListening() = appWidgetHost.stopListening()

    fun allocateAppWidgetId(): Int = appWidgetHost.allocateAppWidgetId()

    fun deleteAppWidgetId(id: Int) = appWidgetHost.deleteAppWidgetId(id)

    /** Intent système officiel pour choisir un widget parmi ceux proposés par les apps installées. */
    fun createPickIntent(appWidgetId: Int): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }

    fun createHostView(appWidgetId: Int): AppWidgetHostView? {
        val info = appWidgetManager.getAppWidgetInfo(appWidgetId) ?: return null
        val view = appWidgetHost.createView(context, appWidgetId, info)
        view.setAppWidget(appWidgetId, info)
        return view
    }
}
